package com.jbravo.super_auto_pets.mascotas.tier2;
import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class PuercoEspin extends Mascota {
    public PuercoEspin(){
        super.setTier(2);
        super.nombreMascota = "Puerco Espin";
        super.id = 12;

        super.unidadesDeDanio = 3;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.solitario + TiposDeMascotas.separador + TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }

}
