package com.jbravo.super_auto_pets.powerups.campos;

import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Campo;

public class Granja extends Campo {

    public Granja(){
        super.setNombre("Granja");
        super.setInfo("Buff a doméstico/mamífero -> nerfeo a solitario"); //tomo el mismo funcionamiento de bosque al no ser especifico
    }

    @Override
    public void bonificacionCampo() {

        int contadorDomestico = 0;
        int contadorMamifero = 0;

        for (int i = 0; i < 5; i++){
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.domestico)){contadorDomestico = contadorDomestico + 2;}
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.mamifero)){contadorMamifero = contadorMamifero + 2;}
        }
        for (int i = 0; i < 5; i++){ //sumar (+2 / +2) por cada animal de tipo domestico/mamifero en el equipo (en ese orden)
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.domestico) || MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.mamifero)){
                MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeDanio()+contadorDomestico);
                MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeVida()+contadorMamifero);
            }

            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.solitario)){
                if (MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeDanio() >= 4 ) {
                    MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeDanio() - 1);
                }
            }
        }

    }
}
