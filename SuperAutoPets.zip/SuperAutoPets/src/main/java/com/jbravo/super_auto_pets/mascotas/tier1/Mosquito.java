package com.jbravo.super_auto_pets.mascotas.tier1;
import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Mosquito extends Mascota {
    public Mosquito(){
        super.setTier(1);
        super.nombreMascota = "Mosquito";
        super.id = 3;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.volador + TiposDeMascotas.separador;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }


}
