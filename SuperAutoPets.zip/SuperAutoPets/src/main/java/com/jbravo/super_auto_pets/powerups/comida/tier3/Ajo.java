package com.jbravo.super_auto_pets.powerups.comida.tier3;

import com.jbravo.super_auto_pets.powerups.Comida;

public class Ajo extends Comida {
    public Ajo(){
        super.setNombre("Ajo");
        super.setEfecto(true);
        super.setDescripcion(" Es tipo efecto, y le da al animal entregado una armadura que hace que el animal entregado reciba 2 de daño menos");
    }

    @Override
    public void efectoAlRecibirDanio(int posicionMascota){

    }
}
