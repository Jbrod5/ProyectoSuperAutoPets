package com.jbravo.super_auto_pets.mascotas.tier4;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Puma extends Mascota {
    public Puma() {
        super.setTier(4);
        super.nombreMascota = "Puma";
        super.id = 32;

        super.unidadesDeDanio = 3;
        super.unidadesDeVida = 7;
        super.tipos = TiposDeMascotas.mamifero+ TiposDeMascotas.separador + TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
