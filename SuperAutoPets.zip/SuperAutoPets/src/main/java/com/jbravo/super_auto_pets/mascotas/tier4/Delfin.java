package com.jbravo.super_auto_pets.mascotas.tier4;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Delfin extends Mascota {
    public Delfin() {
        super.setTier(4);
        super.nombreMascota = "Delfin";
        super.id = 31;

        super.unidadesDeDanio = 4;
        super.unidadesDeVida = 6;
        super.tipos = TiposDeMascotas.acuatico;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
