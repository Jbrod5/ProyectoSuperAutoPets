package com.jbravo.super_auto_pets.motor;

import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;
import com.jbravo.super_auto_pets.powerups.Campo;
import com.jbravo.super_auto_pets.powerups.campos.*;
import com.jbravo.super_auto_pets.utilidades.LimpiarPantalla;

public class Batalla {

    public Campo campo = ModoDeJuego.campo;

    public void mostrarEquipos(){
        System.out.println("Este es el equipo del jugador :D");
        for(int i = 0; i<5;i++){System.out.println((i+1) + " "+ MotorDeJuego.jugadorA.mascotasAPelear[i].getInfo());}
        System.out.println("\nEste es el equipo del rival >:c");
        for(int i = 0; i<5;i++){System.out.println((i+1) + " "+ MotorDeJuego.jugadorB.mascotasAPelear[i].getInfo());}
        System.out.println(" ");
    }

    public void iniciarBatalla(){
        LimpiarPantalla.limpiarPantalla();

        mostrarEquipos();

        //Primero efectos del campo
        campo.bonificacionCampo();

        //Segundo efectos al inicio de la batalla pero sin entrar en la fase de batalla como tal
        for (int i = 0; i<5; i++){
            MotorDeJuego.jugadorA.mascotasAPelear[i].efectoAlInicio();
            MotorDeJuego.jugadorB.mascotasAPelear[i].efectoAlInicio();
        }

        //Tercero Batalla de Mascotas
        do{
            MotorDeJuego.jugadorA.desplazarMascotas(); //Desplaza las mascotas buscando posicion 0
            MotorDeJuego.jugadorB.desplazarMascotas();
            //Fase uno, atacan ambos y se calcula danio
            MotorDeJuego.jugadorA.mascotasAPelear[0].recibirDanio(MotorDeJuego.jugadorB.mascotasAPelear[0].atacar());
            MotorDeJuego.jugadorB.mascotasAPelear[0].recibirDanio(MotorDeJuego.jugadorA.mascotasAPelear[0].atacar());

            //Fase dos, se verifica si vida es igual a cero, si lo es activar el efecto al morir
            if(MotorDeJuego.jugadorA.mascotasAPelear[0].getUnidadesDeVida() == 0){
             MotorDeJuego.jugadorA.mascotasAPelear[0].efectoAlMorir();}
            if(MotorDeJuego.jugadorB.mascotasAPelear[0].getUnidadesDeVida() == 0){
                MotorDeJuego.jugadorB.mascotasAPelear[0].efectoAlMorir();}

            //Fase tres, si  efectoAlMorir no reemplaza la que muere por otra instancia vacía en su lugar y resta contador jugador
            if(MotorDeJuego.jugadorA.mascotasAPelear[0].getUnidadesDeVida() == 0){
                MotorDeJuego.jugadorA.mascotasAPelear[0] = new MascotaEmpty();
                MotorDeJuego.jugadorA.contadorMascotasVivas = MotorDeJuego.jugadorA.contadorMascotasVivas - 1;}
                MotorDeJuego.jugadorA.contadorMascotasVivas();
            if(MotorDeJuego.jugadorB.mascotasAPelear[0].getUnidadesDeVida() == 0){
                MotorDeJuego.jugadorB.mascotasAPelear[0] = new MascotaEmpty();
                MotorDeJuego.jugadorB.contadorMascotasVivas =   MotorDeJuego.jugadorB.contadorMascotasVivas - 1;}
                MotorDeJuego.jugadorA.contadorMascotasVivas();

        }while(MotorDeJuego.jugadorA.contadorMascotasVivas!=0 && MotorDeJuego.jugadorB.contadorMascotasVivas!=0);
        //ambos deben tener al menos una mascota viva para que la batalla continúe

        //verificar quien gano para darle victorias o quitarle vida al jugador
        if(MotorDeJuego.jugadorA.contadorMascotasVivas == MotorDeJuego.jugadorB.contadorMascotasVivas){
            System.out.println("Es un empate");
        }else{
            if(MotorDeJuego.jugadorA.contadorMascotasVivas > MotorDeJuego.jugadorB.contadorMascotasVivas){
                //Gano jugador A
                System.out.println("¡Ganó el Jugador A con " + MotorDeJuego.jugadorA.contadorMascotasVivas + " mascotas vivas!");
                System.out.println("Sus mascotas vivas resultantes son las siguientes");
                for (int i = 0; i<MotorDeJuego.jugadorA.contadorMascotasVivas; i++){System.out.println((i+1) +" " +  MotorDeJuego.jugadorA.mascotasAPelear[i].getInfo());}
                MotorDeJuego.jugadorA.setContadorVictorias(MotorDeJuego.jugadorA.getContadorVictorias()+1);
                //Perdio jugador B
                System.out.println("Jugador B ha perdido");
                MotorDeJuego.jugadorB.recibirDanio(ModoDeJuego.getContadorRonda());
            }
            if(MotorDeJuego.jugadorB.contadorMascotasVivas > MotorDeJuego.jugadorA.contadorMascotasVivas){
                //Gano jugador B
                System.out.println("¡Ganó el Jugador B con " + MotorDeJuego.jugadorB.contadorMascotasVivas + " mascotas vivas!");
                System.out.println("Sus mascotas vivas resultantes son las siguientes");
                for (int i = 0; i<MotorDeJuego.jugadorB.contadorMascotasVivas; i++){System.out.println((i+1) +" "+ MotorDeJuego.jugadorB.mascotasAPelear[i].getInfo());}
                MotorDeJuego.jugadorB.setContadorVictorias(MotorDeJuego.jugadorB.getContadorVictorias()+1);
                //Perdio jugador A
                System.out.println("Jugador A ha perdido");
                MotorDeJuego.jugadorA.recibirDanio(ModoDeJuego.getContadorRonda());
            }
            if (MotorDeJuego.jugadorB.contadorMascotasVivas == MotorDeJuego.jugadorA.contadorMascotasVivas){
                System.out.println("Es un empate, nadie pierde vida ._ . ");
            }
        }

    }
}
