package com.jbravo.super_auto_pets.mascotas.tier1;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Pescado extends Mascota {

    public Pescado(){
        super.setTier(1);
        super.nombreMascota = "Pescado";
        super.id = 2;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 3;
        super.tipos = TiposDeMascotas.acuatico + TiposDeMascotas.separador;

    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }

}
