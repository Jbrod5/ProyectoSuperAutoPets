package com.jbravo.super_auto_pets.powerups.comida.tier3;

import com.jbravo.super_auto_pets.motor.ModoDeJuego;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class ComidaEnlatada extends Comida {

    public ComidaEnlatada(){
        super.setNombre("Comida enlatada");
        super.setDescripcion("Da a los animales de la tienda y todos los próximos que aparezcan 2 de daño y 1 de vida extra.");
    }

    //boof de la tienda IMPLEMENTAR EN TIENDA
    @Override
    public void cambioMascota(int posicionMascota){
        ModoDeJuego.getTienda().setBoof(true);
    }
}
