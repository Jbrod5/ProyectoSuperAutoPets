package com.jbravo.super_auto_pets.mascotas.tier1;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.mascotas.especiales.GrilloZombie;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Grillo extends Mascota {
    public Grillo(){
        super.setTier(1);
        super.nombreMascota = "Grillo";
        super.id = 4;

        super.unidadesDeDanio = 1;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.insecto + TiposDeMascotas.separador;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        MotorDeJuego.jugadorA.mascotasAPelear[0] = new GrilloZombie(super.experiencia, super.comida);
        //super.comida.efectoAlMorir(0);
    }


}
