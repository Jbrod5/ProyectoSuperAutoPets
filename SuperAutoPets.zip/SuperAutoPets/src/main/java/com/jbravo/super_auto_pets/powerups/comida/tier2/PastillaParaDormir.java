package com.jbravo.super_auto_pets.powerups.comida.tier2;

import com.jbravo.super_auto_pets.powerups.Comida;

public class PastillaParaDormir extends Comida {
    public PastillaParaDormir(){
        super.setNombre("Pastilla para dormir");
        super.setDescripcion("Hace que nuestro animal se desmaye durante la fase de compras.");
    }

    //se desmalla la mascota :c
}
