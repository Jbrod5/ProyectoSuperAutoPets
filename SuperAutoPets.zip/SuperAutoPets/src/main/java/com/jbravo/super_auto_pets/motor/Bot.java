package com.jbravo.super_auto_pets.motor;

import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;

import java.util.Random;

public class Bot extends Entidad{
    int cantidadDeMascotasAGenerar;
    Random random = new Random();
    public Bot(){

    }

    public void generarMascotas() throws CloneNotSupportedException {
        for(int i = 0; i < 5; i++){
            super.mascotasDisponibles[i] = new MascotaEmpty();
            super.mascotasAPelear[i] = new MascotaEmpty();
        }
        if (ModoDeJuego.contadorRonda <=3 && ModoDeJuego.contadorRonda >0){ //solo tres mascotas
            cantidadDeMascotasAGenerar = 3; }
        if( ModoDeJuego.contadorRonda >3 && ModoDeJuego.contadorRonda<=6){ //generar cuatro mascotas
            cantidadDeMascotasAGenerar = 4; }
        if (ModoDeJuego.contadorRonda >= 7){ //generar cinco mascotas
            cantidadDeMascotasAGenerar = 5; }

        switch (ModoDeJuego.tier) {
            case 1: for (int i = 0; i < cantidadDeMascotasAGenerar; i++) {
                super.contadorMascotasVivas++;
                super.mascotasDisponibles[i] = ListadoMascotas.tier1(random.nextInt(8) + 1);}
                break;
            case 2: for (int i = 0; i < cantidadDeMascotasAGenerar; i++) {
                super.contadorMascotasVivas++;
                super.mascotasDisponibles[i] = ListadoMascotas.tier2(random.nextInt(8) + 1);}
                break;
            case 3: for (int i = 0; i < cantidadDeMascotasAGenerar; i++) {
                super.contadorMascotasVivas++;
                super.mascotasDisponibles[i] = ListadoMascotas.tier3(random.nextInt(11) + 1);}
                break;
            case 4: for (int i = 0; i < cantidadDeMascotasAGenerar; i++) {
                super.contadorMascotasVivas++;
                super.mascotasDisponibles[i] = ListadoMascotas.tier4(random.nextInt(8) + 1);}
                break;
            case 5: for (int i = 0; i < cantidadDeMascotasAGenerar; i++) {
                super.contadorMascotasVivas++;
                super.mascotasDisponibles[i] = ListadoMascotas.tier5(random.nextInt(8) + 1);}
                break;
            case 6: for (int i = 0; i < cantidadDeMascotasAGenerar; i++) {
                super.contadorMascotasVivas++;
                super.mascotasDisponibles[i] = ListadoMascotas.tier6(random.nextInt(9) + 1);}
                break;
            case 7: for (int i = 0; i < cantidadDeMascotasAGenerar; i++) {
                super.contadorMascotasVivas++;
                super.mascotasDisponibles[i] = ListadoMascotas.tier7(random.nextInt(2) + 1);}
                break;
        }
        super.ordenarMascotasPorVida(true);
        super.cargarEquipo();
    }
}
