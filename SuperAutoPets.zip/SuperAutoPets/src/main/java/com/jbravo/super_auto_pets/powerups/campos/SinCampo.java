package com.jbravo.super_auto_pets.powerups.campos;

import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.motor.ListadoMascotas;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Campo;

public class SinCampo extends Campo {

    public SinCampo(){
        super.setNombre("Sin Campo");
        super.setInfo("Los solitarios ganan una bonificación de (+3/+3) si solo hay uno en el equipo");
    }

    @Override
    public void bonificacionCampo() {
        int contadorSolitarios = 0;
        int posicionSolitario = 0;
        for (int i = 0; i < 5; i++){
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.solitario)){
                contadorSolitarios ++;
                posicionSolitario = i;
            }
        }
        if (contadorSolitarios == 1){
            //Aumentar (+3 / +3)
            MotorDeJuego.jugadorA.mascotasAPelear[posicionSolitario].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[posicionSolitario].getUnidadesDeVida()+3);
            MotorDeJuego.jugadorA.mascotasAPelear[posicionSolitario].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[posicionSolitario].getUnidadesDeDanio()+3);
        }
    }
}
