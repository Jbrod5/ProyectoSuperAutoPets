package com.jbravo.super_auto_pets.mascotas.tier6;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Gorila extends Mascota {
    public Gorila() {
        super.setTier(6);
        super.nombreMascota = "Gorila";
        super.id = 50;

        super.unidadesDeDanio = 6;
        super.unidadesDeVida = 9;
        super.tipos = TiposDeMascotas.mamifero + TiposDeMascotas.separador + TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
