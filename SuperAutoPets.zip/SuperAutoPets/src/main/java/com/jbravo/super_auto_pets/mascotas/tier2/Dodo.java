package com.jbravo.super_auto_pets.mascotas.tier2;
import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Dodo extends Mascota {
        public Dodo(){
            super.setTier(2);
            super.nombreMascota = "Dodo";
            super.id = 10;

            super.unidadesDeDanio = 2;
            super.unidadesDeVida = 3;
            super.tipos = TiposDeMascotas.volador;
        }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
