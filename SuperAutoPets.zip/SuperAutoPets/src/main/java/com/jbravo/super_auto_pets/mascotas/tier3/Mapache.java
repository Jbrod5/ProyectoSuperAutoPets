package com.jbravo.super_auto_pets.mascotas.tier3;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Mapache extends Mascota {
    public Mapache() {
        super.setTier(3);
        super.nombreMascota = "Mapache";
        super.id = 18;

        super.unidadesDeDanio = 5;
        super.unidadesDeVida = 4;
        super.tipos = TiposDeMascotas.solitario ;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}