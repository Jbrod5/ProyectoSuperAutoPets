package com.jbravo.super_auto_pets;

import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.utilidades.LimpiarPantalla;

import java.util.Scanner;

public class SuperAutoPets {

    public static void main(String [] args ) throws CloneNotSupportedException{
        String opcion;
        Scanner scanner = new Scanner(System.in);
        do{
            System.out.println("  _____ _    _ _____  ______ _____            _    _ _______ ____  \n" +
                    " / ____| |  | |  __ \\|  ____|  __ \\      /\\  | |  | |__   __/ __ \\ \n" +
                    "| (___ | |  | | |__) | |__  | |__) |    /  \\ | |  | |  | | | |  | |\n" +
                    " \\___ \\| |  | |  ___/|  __| |  _  /    / /\\ \\| |  | |  | | | |  | |\n" +
                    " ____) | |__| | |    | |____| | \\ \\   / ____ \\ |__| |  | | | |__| |\n" +
                    "|_____/ \\____/|_|    |______|_|  \\_\\ /_/    \\_\\____/   |_|  \\____/ \n" +
                    "                                                                   \n" +
                    "                                                                   \n" +
                    "                   _____  ______ _______ _____ \n" +
                    "                  |  __ \\|  ____|__   __/ ____|\n" +
                    "                  | |__) | |__     | | | (___  \n" +
                    "                  |  ___/|  __|    | |  \\___ \\ \n" +
                    "                  | |    | |____   | |  ____) |\n" +
                    "                  |_|    |______|  |_| |_____/");
            System.out.println("\n Ingrese p para jugar, s para salir");
            opcion = scanner.nextLine();
            if(opcion.equals("p") || opcion.equals("P")){
                LimpiarPantalla.limpiarPantalla();
                MotorDeJuego.modoa.Juego();
            }

        }while(!opcion.equals("s"));
    }
}
