package com.jbravo.super_auto_pets.powerups.comida.tier6;

import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

import java.util.Random;

public class Pizza extends Comida {

    public Pizza() {
        super.setNombre("Pizza");
        super.setDescripcion(" Da 2 de vida y 2 de daño a 2 animales randoms de tu equipo");
    }

    @Override
    public void cambioMascota(int posicionMascota) {
        Random random = new Random();

        //Da 2 de danio y 2 de ataque a dos mascotas random en el equipo

        int posicion1;
        int posicion2;
        do{
            posicion1 = random.nextInt(5);
            posicion2 = random.nextInt(5);
        }while(MotorDeJuego.jugadorA.mascotasAPelear[posicion1] instanceof MascotaEmpty && MotorDeJuego.jugadorA.mascotasAPelear[posicion2] instanceof MascotaEmpty);
        MotorDeJuego.jugadorA.mascotasAPelear[posicion1].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[posicion1].getUnidadesDeDanio()+2);
        MotorDeJuego.jugadorA.mascotasAPelear[posicion1].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[posicion1].getUnidadesDeVida()+2);

        MotorDeJuego.jugadorA.mascotasAPelear[posicion2].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[posicion2].getUnidadesDeDanio()+2);
        MotorDeJuego.jugadorA.mascotasAPelear[posicion2].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[posicion2].getUnidadesDeVida()+2);


        MotorDeJuego.jugadorA.mascotasDisponibles[posicion1].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasDisponibles[posicion1].getUnidadesDeDanio()+2);
        MotorDeJuego.jugadorA.mascotasDisponibles[posicion1].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasDisponibles[posicion1].getUnidadesDeVida()+2);

        MotorDeJuego.jugadorA.mascotasDisponibles[posicion2].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasDisponibles[posicion2].getUnidadesDeDanio()+2);
        MotorDeJuego.jugadorA.mascotasDisponibles[posicion2].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasDisponibles[posicion2].getUnidadesDeVida()+2);
    }
}
