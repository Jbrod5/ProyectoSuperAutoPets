package com.jbravo.super_auto_pets.motor;

import com.jbravo.super_auto_pets.powerups.Comida;
import com.jbravo.super_auto_pets.powerups.comida.tier1.*;
import com.jbravo.super_auto_pets.powerups.comida.tier2.*;
import com.jbravo.super_auto_pets.powerups.comida.tier3.*;
import com.jbravo.super_auto_pets.powerups.comida.tier4.*;
import com.jbravo.super_auto_pets.powerups.comida.tier5.*;
import com.jbravo.super_auto_pets.powerups.comida.tier6.*;
import com.jbravo.super_auto_pets.powerups.comida.tier7.Gelatina;

import java.util.Random;

public class ListadoComidas {
    static Random random = new Random();

    public static Comida tier1(int rango1a3){
        switch (rango1a3){
            case 1: return new Manzana();
            case 2: return new Naranja();
            case 3: return new Miel();
            default: return new Manzana();
        }
    }

    public static Comida tier2(int rango1a4){
        switch (rango1a4){
            case 1: return new Pastelito();
            case 2: return new HuesoDeCarne();
            case 3: return new PastillaParaDormir();
            default: return tier1(random.nextInt(3)+1);
        }
    }

    public static Comida tier3(int rango1a6){//6 = 4 comidas + 2 tiers
        switch (rango1a6){
            case 1:return new Ajo();
            case 2:return new Ensalada();
            case 3:return new ComidaEnlatada();
            case 4:return new Pera();
            case 5: return tier1(random.nextInt(3)+1);
            default:return tier2(random.nextInt(4)+1);
        }
    }

    public static Comida tier4(int rango1a6){// 6 = 3 comidas + 3 tiers
        switch (rango1a6) {
            case 1: return new Chile();
            case 2: return new Chocolate();
            case 3: return new Sushi();
            case 4: return tier1(random.nextInt(3)+1);
            case 5: return  tier2(random.nextInt(4)+1);
            default: return tier3(random.nextInt(6)+1);
        }
    }

    public static Comida tier5(int rango1a3){// 3 = 2 comidas + 1 tier anterior que contiene a los demás anteriores
        switch (rango1a3){
            case 1: return new Melon();
            case 2: return new Hongo();
            default: return tier4(random.nextInt(6)+1);
        }
    }

    public static Comida tier6(int rango1a3){
        switch (rango1a3){
            case 1: return new Pizza();
            case 2: return new Carne();
            default: return tier5(random.nextInt(3)+1);
        }
    }

    public static Comida tier7(int rango1a2){
        switch (rango1a2){
            case 1: return new Gelatina();
            default: return tier6(random.nextInt(3)+1);
        }
    }

}
