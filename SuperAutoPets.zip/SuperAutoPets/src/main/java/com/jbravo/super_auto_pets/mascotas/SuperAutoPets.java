package com.jbravo.super_auto_pets.mascotas;
import com.jbravo.super_auto_pets.mascotas.tier1.Hormiga;
import com.jbravo.super_auto_pets.motor.*;

import java.util.Random;

public class SuperAutoPets {

    public static void main (String[] args) throws CloneNotSupportedException {
       /* Hormiga h1 = new Hormiga(25);
        h1.efectoAlInicio();*/

/*        Hormiga h1 = new Hormiga();
        h1.efectoAlInicio();

*/

        System.out.println("  _____ _    _ _____  ______ _____            _    _ _______ ____  \n" +
                " / ____| |  | |  __ \\|  ____|  __ \\      /\\  | |  | |__   __/ __ \\ \n" +
                "| (___ | |  | | |__) | |__  | |__) |    /  \\ | |  | |  | | | |  | |\n" +
                " \\___ \\| |  | |  ___/|  __| |  _  /    / /\\ \\| |  | |  | | | |  | |\n" +
                " ____) | |__| | |    | |____| | \\ \\   / ____ \\ |__| |  | | | |__| |\n" +
                "|_____/ \\____/|_|    |______|_|  \\_\\ /_/    \\_\\____/   |_|  \\____/ \n" +
                "                                                                   \n" +
                "                                                                   \n" +
                "                   _____  ______ _______ _____ \n" +
                "                  |  __ \\|  ____|__   __/ ____|\n" +
                "                  | |__) | |__     | | | (___  \n" +
                "                  |  ___/|  __|    | |  \\___ \\ \n" +
                "                  | |    | |____   | |  ____) |\n" +
                "                  |_|    |______|  |_| |_____/");

        System.out.println("probando la tienda ");
        //MotorDeJuego motorDeJuego = new MotorDeJuego();
        MotorDeJuego.modoa.Juego();



        Random random = new Random();
        System.out.println("generar numero aleatorio usando random");
        for (int i = 0; i<12; i++){
            System.out.println(random.nextInt(8)+1);
        }

        Pelea pelea = new Pelea();

        do {
            pelea.iniciarCombate();
        }while (pelea.jugadorA.contadorMascotasVivas!=0 && pelea.jugadorB.contadorMascotasVivas!=0);


        Entidad jugador = new Jugador();
        jugador.mascotasDisponibles[0] = new MascotaEmpty();
        jugador.mascotasDisponibles[1] = new MascotaEmpty();
        jugador.mascotasDisponibles[2] = new Hormiga();
        jugador.mascotasDisponibles[3] = new MascotaEmpty();
        jugador.mascotasDisponibles[4] = new Perro();

        jugador.contadorMascotasVivas = 2;

        jugador.desplazarMascotas();
        jugador.mascotasDisponibles[0].efectoAlInicio();
        jugador.mascotasDisponibles[1].efectoAlInicio();
        if (jugador.mascotasDisponibles[2] instanceof MascotaEmpty){
            System.out.println("soy null");
        }

        //PROBANDO ORDENAMIENTO ASCENDENTE DESCENDENTE -FUNCIONA
        System.out.println("se ordenaran de manera descendente");
        jugador.ordenarMascotasPorTier(true);
        System.out.println("se ordenaran de manera ascendete");
        jugador.ordenarMascotasPorTier(false);

        jugador.ordenarMascotasArbitrario(); //ORDENAR MASCOTA ARBITRARIO FUNCIONA
        for (int i = 0; i<5;i++){
            System.out.println(jugador.mascotasDisponibles[i].getInfo());
        }
        /*
        Mascota [] mascota = new Mascota[5];
        mascota[0] = new Hormiga();
        mascota[1] = new Hormiga();
        mascota[2] = new Perro();
        mascota[3] = new Hormiga();
        mascota[4] = new Perro();

        mascota[0] = mascota[2];
*/

        /*for(int i = 0; i < 5; i++){
           mascota[i].efectoAlInicio();

        }*/


    }
}
