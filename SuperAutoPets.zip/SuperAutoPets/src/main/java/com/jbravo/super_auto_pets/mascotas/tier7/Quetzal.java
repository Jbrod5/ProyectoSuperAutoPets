package com.jbravo.super_auto_pets.mascotas.tier7;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Quetzal extends Mascota {
    public Quetzal() {
        super.setTier(7);
        super.nombreMascota = "Quetzal";
        super.id = 53;

        super.unidadesDeDanio = 10;
        super.unidadesDeVida = 10;
        super.tipos = TiposDeMascotas.volador + TiposDeMascotas.separador + TiposDeMascotas.solitario;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
