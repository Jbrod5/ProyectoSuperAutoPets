package com.jbravo.super_auto_pets.powerups.comida.tier4;

import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Chocolate extends Comida {
    public Chocolate(){
        super.setNombre("Chocolate");
        super.setDescripcion(" Da +1 de experiencia a un animal de tu equipo");
    }

    @Override
    public void cambioMascota(int posicionMascota){
        //suma 1 de experiencia a la mascota que la reciba
        MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setExperiencia(MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].getExperiencia()+1);
    }

}
