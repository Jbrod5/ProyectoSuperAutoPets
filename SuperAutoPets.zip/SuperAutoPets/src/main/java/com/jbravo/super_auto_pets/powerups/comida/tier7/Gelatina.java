package com.jbravo.super_auto_pets.powerups.comida.tier7;

import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

import java.util.Scanner;

public class Gelatina extends Comida {

    public Gelatina(){
        super.setEfecto(true);
        super.setNombre("Gelatina");
        super.setDescripcion(" Es tipo efecto, y hace que el animal que lo porté tenga un tipo extra que escoge el jugador.");
    }

    @Override
    public void cambioMascota(int posicionMascota) {
        String nuevoTipo = " ";
        System.out.println("Estos son los tipos que puede elegir para agregar a la mascota seleccionada");
        System.out.println("1. " + TiposDeMascotas.insecto);
        System.out.println("2. " + TiposDeMascotas.volador);
        System.out.println("3. " + TiposDeMascotas.acuatico);
        System.out.println("4. " + TiposDeMascotas.terrestre);
        System.out.println("5. " + TiposDeMascotas.reptil);
        System.out.println("6. " + TiposDeMascotas.mamifero);
        System.out.println("7. " + TiposDeMascotas.domestico);
        System.out.println("8. " + TiposDeMascotas.solitario);
        System.out.println("9. " + TiposDeMascotas.desertico);
        System.out.println("Ingrese la posicion del tipo que desea agregar");
        Scanner scanner = new Scanner(System.in);

        int opcion = 0;
        boolean esCorrecto = false;
            while (!esCorrecto){
                try{
                    opcion = scanner.nextInt();
                    esCorrecto = true;
                }catch (Exception e){
                    System.out.println("El valor ingresado no es correcto, ingrese otro por favor");
                    scanner.next();
                }
            }
        switch (opcion){
            case 1: nuevoTipo = TiposDeMascotas.insecto;    break;
            case 2: nuevoTipo = TiposDeMascotas.volador;    break;
            case 3: nuevoTipo = TiposDeMascotas.acuatico;   break;
            case 4: nuevoTipo = TiposDeMascotas.terrestre;  break;
            case 5: nuevoTipo = TiposDeMascotas.reptil;     break;
            case 6: nuevoTipo = TiposDeMascotas.mamifero;   break;
            case 7: nuevoTipo = TiposDeMascotas.domestico;  break;
            default:nuevoTipo = TiposDeMascotas.solitario;  break;
        }

        MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setTipos(MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].getTipos() + TiposDeMascotas.separador + nuevoTipo);
    }
}
