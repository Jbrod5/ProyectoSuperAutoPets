package com.jbravo.super_auto_pets.powerups.comida.tier3;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

import java.util.Random;

public class Ensalada extends Comida {

    public Ensalada(){
        super.setNombre("Ensalada");
        super.setDescripcion(" Da 1 de vida y 1 de daño a 2 animales aleatorios de tu equipo");
    }

    @Override
    public void cambioMascota(int posicionMascota){
        Random random = new Random();
        int posicion1;
        int posicion2;
        do{
            posicion1 = random.nextInt(5);
            posicion2 = random.nextInt(5);
        }while(MotorDeJuego.jugadorA.mascotasAPelear[posicion1] instanceof MascotaEmpty && MotorDeJuego.jugadorA.mascotasAPelear[posicion2] instanceof MascotaEmpty);
        MotorDeJuego.jugadorA.mascotasAPelear[posicion1].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[posicion1].getUnidadesDeDanio()+1);
        MotorDeJuego.jugadorA.mascotasAPelear[posicion1].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[posicion1].getUnidadesDeVida()+1);

        MotorDeJuego.jugadorA.mascotasAPelear[posicion2].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[posicion2].getUnidadesDeDanio()+1);
        MotorDeJuego.jugadorA.mascotasAPelear[posicion2].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[posicion2].getUnidadesDeVida()+1);


        MotorDeJuego.jugadorA.mascotasDisponibles[posicion1].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasDisponibles[posicion1].getUnidadesDeDanio()+1);
        MotorDeJuego.jugadorA.mascotasDisponibles[posicion1].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasDisponibles[posicion1].getUnidadesDeVida()+1);

        MotorDeJuego.jugadorA.mascotasDisponibles[posicion2].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasDisponibles[posicion2].getUnidadesDeDanio()+1);
        MotorDeJuego.jugadorA.mascotasDisponibles[posicion2].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasDisponibles[posicion2].getUnidadesDeVida()+1);

    }

}
