package com.jbravo.super_auto_pets.mascotas;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;
import com.jbravo.super_auto_pets.powerups.comida.ComidaEmpty;

    public abstract class Mascota implements Cloneable{                  //abstract solo permite que sea heredada
    protected int tier;
    protected String nombreMascota;
    protected int id;
    protected int posicion;
    protected boolean turno;                     //puedo retirar esta si el turno se mide conforme a la vida
    protected boolean vidaExtra = false;
    protected boolean carne = false;

    protected double unidadesDeDanio =0;
    protected double unidadesDeVida = 0;
    protected int experiencia = 1;               //Todas las mascotas inician con 1 de exp || experiencia es el nivel
    protected String tipos;
    protected boolean desmayado = false;         //indica si una mascota está desmayada (por defecto no lo está)
    protected boolean proteccionDanio = false;   //si es verdadera no recibe daño ese turno
    protected double reduccionDanioRecibido = 0; //reduce el daño recibido (por defecto no lo reduce)
    protected double aumentoDanioAtaque = 0;     //indica en cuánto se aumenta el daño al atacar (por defecto no lo aumenta)
    protected boolean comidaEfecto = false;      //indica si hay equipada una comida con efecto (por defecto no la hay)

    protected Comida comida = new ComidaEmpty(); //Guarda comida de tipo efecto, solo hay uno porque solo se puede portar 1 a la vez
    //protected Comida [] comida = new Comida[20];//array de powerups de tipo comida
    //protected Efecto [] efecto = new Efecto[20];//array de powerups de tipo efecto

    public Mascota(){ }

    @Override
    public Object clone() throws CloneNotSupportedException{
        return super.clone();
    }

    //METODOS DE EFECTOS----------------------------------------------------------------------------
    public abstract void efectoAlInicio();
    public abstract void efectoEnTurno();
    public abstract void efectoAlSubirDeNivel();
    public abstract void efectoAlMorir();
    //ACCIONES ATACAR Y RECIBIR DAÑO----------------------------------------------------------------
    public void recibirDanio(double danioARecibir){
        comida.efectoAlRecibirDanio(0); //si recibe danio es porque esta en la posicion 0 por despl de array
        if(this.proteccionDanio){
            System.out.println("Jeje " + getNombreMascota() + " tenia proteccion de danio :3");
            proteccionDanio = false; //quita la proteccion despues de un uso
        }else{
            this.unidadesDeVida = this.unidadesDeVida - danioARecibir;
            if(this.unidadesDeVida<0){
                this.unidadesDeVida = 0;
            }
        }
    }
    public double atacar(){
        if (carne){
            this.carne = false;
            return unidadesDeDanio + 20; //da 20 de danio adicional una vez por ronda
        }
        return unidadesDeDanio;
    }

    //getters y setters-----------------------------------------------------------------------------
    public String getInfo(){
        return "Nombre: " + nombreMascota + " Tier: " + tier + " Ataque: " + unidadesDeDanio + " Vida: " + unidadesDeVida + " Nivel: " + experiencia;
    }
    public int getTier() {
        return tier;
    }
    public void setTier(int tier) {
        this.tier = tier;
    }
    public String getNombreMascota() {
        return nombreMascota;
    }
    public void setNombreMascota(String nombreMascota) {
        this.nombreMascota = nombreMascota;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public boolean isTurno() {
        return turno;
    }
    public void setTurno(boolean turno) {
        this.turno = turno;
    }
    public double getUnidadesDeDanio() {
        return unidadesDeDanio;
    }
    public void setUnidadesDeDanio(double unidadesDeDanio) {
        this.unidadesDeDanio = unidadesDeDanio;
    }
    public double getUnidadesDeVida() {
        return unidadesDeVida;
    }
    public void setUnidadesDeVida(double unidadesDeVida) {
        this.unidadesDeVida = unidadesDeVida;
    }
    public int getExperiencia() {
        return experiencia;
    }
    public void setExperiencia(int experiencia) {
        this.experiencia = experiencia;
    }
    public String getTipos() {
        return tipos;
    }
    public void setTipos(String tipos) {
        this.tipos = tipos;
    }
    public boolean isDesmayado() {
        return desmayado;
    }
    public void setDesmayado(boolean desmayado) {
        this.desmayado = desmayado;
    }
    public boolean isProteccionDanio() {
        return proteccionDanio;
    }
    public void setProteccionDanio(boolean proteccionDanio) {
        this.proteccionDanio = proteccionDanio;
    }
    public double getReduccionDanioRecibido() {
        return reduccionDanioRecibido;
    }
    public void setReduccionDanioRecibido(double reduccionDanioRecibido) {this.reduccionDanioRecibido = reduccionDanioRecibido;}
    public double getAumentoDanioAtaque() {
        return aumentoDanioAtaque;
    }
    public void setAumentoDanioAtaque(double aumentoDanioAtaque) {
        this.aumentoDanioAtaque = aumentoDanioAtaque;
    }
    public boolean isComidaEfecto() {
        return comidaEfecto;
    }
    public void setComidaEfecto(boolean comidaEfecto) {
        this.comidaEfecto = comidaEfecto;
    }
    public boolean isVidaExtra() {return vidaExtra;}
    public void setVidaExtra(boolean vidaExtra) {this.vidaExtra = vidaExtra;}
    public boolean isCarne() {return carne;}
    public void setCarne(boolean carne) {this.carne = carne;}

    public Comida getComida() {return comida;}
    public void setComida(Comida comida) {this.comida = comida;}
}
