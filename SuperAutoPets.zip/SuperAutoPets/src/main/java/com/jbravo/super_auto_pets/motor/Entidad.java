package com.jbravo.super_auto_pets.motor;
import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;

import java.util.Scanner;

public abstract class Entidad {

    public int vida = 10;
    public int oro;
    public int contadorMascotasVivas = 0;
    public int contadorVictorias = 0;
    public Mascota [] mascotasDisponibles = new Mascota[5]; //equipo no destructivo
    public Mascota [] mascotasAPelear = new Mascota[5];     //equipo destructivo durante combates


    public Entidad(){
        for (int i = 0; i<5; i++){
            mascotasDisponibles[i] = new MascotaEmpty();
            mascotasAPelear[i] = new MascotaEmpty();
        }
    }

    //Formas de ordenar: arbitrario por el jugador / tier a-d/ vida a-d / danio a-d
    public void ordenarMascotasArbitrario(){ //Intercambia las mascotas en base a unas posiciones especificadas por el jugador

        Scanner scanner = new Scanner(System.in);
        System.out.println("Intercambiara las posiciones de las mascotas de manera arbitraria");
        System.out.println("Por favor, ingrese las posiciones de las mascotas que desean intercambiar");
        System.out.println("Si ingresa posiciones no validas se se repetira la accion");
        System.out.println("1. "+ mascotasDisponibles[0].getInfo());
        System.out.println("2. "+ mascotasDisponibles[1].getInfo());
        System.out.println("3. "+ mascotasDisponibles[2].getInfo());
        System.out.println("4. "+ mascotasDisponibles[3].getInfo());
        System.out.println("5. "+ mascotasDisponibles[4].getInfo());

        int posicionA;
        int posicionB;
        do {
            System.out.println("Ingrese la posicion 1 a intercambiar");
            posicionA = Integer.parseInt(scanner.nextLine())-1;
            System.out.println("Ingrese la posicion 2 a intercambiar");
            posicionB = Integer.parseInt(scanner.nextLine())-1;
        }while ((posicionA >=5 || posicionB >=5) || (posicionA <0 || posicionB <0));

        Mascota transitoriaA;
        Mascota transitoriaB;
        Mascota transitoriaC;
        Mascota transitoriaD;

        transitoriaA = mascotasDisponibles[posicionA];
        transitoriaB = mascotasDisponibles[posicionB];

        mascotasDisponibles[posicionA] = transitoriaB; //intercambio de posiciones
        mascotasDisponibles[posicionB] = transitoriaA;

        transitoriaC = mascotasAPelear[posicionA];
        transitoriaD = mascotasAPelear[posicionB];

        mascotasAPelear[posicionA] = transitoriaD; //intercambio de posiciones
        mascotasAPelear[posicionB] = transitoriaC;
        //scanner.close();
    }
    public void ordenarMascotasPorTier(boolean descendente){ //recibe parametro v/f
        Mascota transitoriaA;
        Mascota transitoriaB;
        if(descendente){
            for (int i = 0; i < 5; i++){ //ordena descendente
                for (int j = i+1; j < 5; j++){
                    if(mascotasDisponibles[i].getTier() < mascotasDisponibles[j].getTier()){
                        transitoriaA = mascotasDisponibles[i];
                        transitoriaB = mascotasDisponibles[j];
                        mascotasDisponibles[i] = transitoriaB;
                        mascotasDisponibles[j] = transitoriaA;
                    }
                    if(mascotasAPelear[i].getTier() < mascotasAPelear[j].getTier()){
                        transitoriaA = mascotasAPelear[i];
                        transitoriaB = mascotasAPelear[j];
                        mascotasAPelear[i] = transitoriaB;
                        mascotasAPelear[j] = transitoriaA;
                    }
                }
            }
        }else{ //ordena ascendente
            for (int i = 0; i < 5; i++){
                for (int j = i+1; j < 5; j++){
                    if(mascotasDisponibles[i].getTier() > mascotasDisponibles[j].getTier()){
                        transitoriaA = mascotasDisponibles[i];
                        transitoriaB = mascotasDisponibles[j];
                        mascotasDisponibles[i] = transitoriaB;
                        mascotasDisponibles[j] = transitoriaA;
                    }
                    if(mascotasAPelear[i].getTier() > mascotasAPelear[j].getTier()){
                        transitoriaA = mascotasAPelear[i];
                        transitoriaB = mascotasAPelear[j];
                        mascotasAPelear[i] = transitoriaB;
                        mascotasAPelear[j] = transitoriaA;
                    }
                }
            }
        }
    }
    public void ordenarMascotasPorVida(boolean descendente){//recibe parametro v/f
        Mascota transitoriaA;
        Mascota transitoriaB;
        if(descendente){
            for (int i = 0; i < 5; i++){ //ordena descendente
                for (int j = i+1; j < 5; j++){
                    if(mascotasDisponibles[i].getUnidadesDeVida() < mascotasDisponibles[j].getUnidadesDeVida()){
                        transitoriaA = mascotasDisponibles[i];
                        transitoriaB = mascotasDisponibles[j];
                        mascotasDisponibles[i] = transitoriaB;
                        mascotasDisponibles[j] = transitoriaA;
                    }
                    if(mascotasAPelear[i].getUnidadesDeVida() < mascotasAPelear[j].getUnidadesDeVida()){
                        transitoriaA = mascotasAPelear[i];
                        transitoriaB = mascotasAPelear[j];
                        mascotasAPelear[i] = transitoriaB;
                        mascotasAPelear[j] = transitoriaA;
                    }
                }
            }
        }else{ //ordena ascendente
            for (int i = 0; i < 5; i++){
                for (int j = i+1; j < 5; j++){
                    if(mascotasDisponibles[i].getUnidadesDeVida() > mascotasDisponibles[j].getUnidadesDeVida()){
                        transitoriaA = mascotasDisponibles[i];
                        transitoriaB = mascotasDisponibles[j];
                        mascotasDisponibles[i] = transitoriaB;
                        mascotasDisponibles[j] = transitoriaA;
                    }
                }
            }
        }
    }
    public void ordenarMascotasPorDanio(boolean descendente){ //recibe parametro v/f
        Mascota transitoriaA;
        Mascota transitoriaB;
        if(descendente){
            for (int i = 0; i < 5; i++){ //ordena descendente
                for (int j = i+1; j < 5; j++){
                    if(mascotasDisponibles[i].getUnidadesDeDanio() < mascotasDisponibles[j].getUnidadesDeDanio()){
                        transitoriaA = mascotasDisponibles[i];
                        transitoriaB = mascotasDisponibles[j];
                        mascotasDisponibles[i] = transitoriaB;
                        mascotasDisponibles[j] = transitoriaA;
                    }
                    if(mascotasAPelear[i].getUnidadesDeDanio() < mascotasAPelear[j].getUnidadesDeDanio()){
                        transitoriaA = mascotasAPelear[i];
                        transitoriaB = mascotasAPelear[j];
                        mascotasAPelear[i] = transitoriaB;
                        mascotasAPelear[j] = transitoriaA;
                    }
                }
            }
        }else{ //ordena ascendente
            for (int i = 0; i < 5; i++){
                for (int j = i+1; j < 5; j++){
                    if(mascotasDisponibles[i].getUnidadesDeDanio() > mascotasDisponibles[j].getUnidadesDeDanio()){
                        transitoriaA = mascotasDisponibles[i];
                        transitoriaB = mascotasDisponibles[j];
                        mascotasDisponibles[i] = transitoriaB;
                        mascotasDisponibles[j] = transitoriaA;
                    }
                    if(mascotasAPelear[i].getUnidadesDeDanio() > mascotasAPelear[j].getUnidadesDeDanio()){
                        transitoriaA = mascotasAPelear[i];
                        transitoriaB = mascotasAPelear[j];
                        mascotasAPelear[i] = transitoriaB;
                        mascotasAPelear[j] = transitoriaA;
                    }
                }
            }
        }
    }
    public void desplazarMascotas(){ //quita los espacios nulos y desplaza el array hasta la primera posicion
        int contadorNotNull = 0; // este desplaza el equipo inmutable
        for (int i = 0; i<5; i++){
            contadorNotNull = 0;
            if(mascotasDisponibles[i] instanceof MascotaEmpty){
                for (int j = i+1; j<5 && contadorNotNull!=1; j++){
                    if(mascotasDisponibles[j] instanceof MascotaEmpty){
                        int a = 1;
                    }else {
                        mascotasDisponibles[i] = mascotasDisponibles[j];
                        mascotasDisponibles[j] = new MascotaEmpty();
                        contadorNotNull = 1;
                    }
                }
            }
        }

        int contadorNotNullPelea = 0; //este desplaza en la pelea
        for (int i = 0; i<5; i++){
            contadorNotNullPelea = 0;
            if(mascotasAPelear[i] instanceof MascotaEmpty){
                for (int j = i+1; j<5 && contadorNotNullPelea!=1; j++){
                    if(mascotasAPelear[j] instanceof MascotaEmpty){
                        int a = 1;
                    }else {
                        mascotasAPelear[i] = mascotasAPelear[j];
                        mascotasAPelear[j] = new MascotaEmpty();
                        contadorNotNullPelea = 1;
                    }
                }
            }
        }
    }

    public void cargarEquipo() throws CloneNotSupportedException { //Usado solamente en peleas
        for (int i = 0; i<5; i++) {
            mascotasAPelear[i] = (Mascota) mascotasDisponibles[i].clone();
        }
    }//carga el equipo en array destructivo para combates

    public void recibirDanio(int contadorRonda){
        if(contadorRonda > 0 && contadorRonda< 4){
            vida = vida - 1;
            System.out.println("Ha perdido 1 de vida :c");
        }
        if (contadorRonda > 3 && contadorRonda < 7){
            vida = vida - 2;
            System.out.println("Ha perdido 2 de vida :'c");
        }
        if (contadorRonda > 6 ){
            vida = vida - 3;
            System.out.println("Ha perdido 3 de vida :'''cccc");
        }
        if (vida < 0){
            vida = 0;
        }
    }

    public void recuperarContadorMascotasVivas(){
        for (int i = 0; i<5; i++){
            if(mascotasDisponibles[i] instanceof MascotaEmpty){

            }else{
                contadorMascotasVivas ++;
            }
        }
    }

    public void contadorMascotasVivas(){
        contadorMascotasVivas = 0;
        for (int i = 0; i<5; i++){
            if(mascotasAPelear[i] instanceof MascotaEmpty){

            }else{
                contadorMascotasVivas ++;
            }
        }
    }
    //------------------------------ GETTERS Y SETTERS ------------------------------
    public int getVida() {return vida;}
    public void setVida(int vida) {this.vida = vida;}
    public int getOro() {return oro;}
    public void setOro(int oro) {this.oro = oro;}
    public Mascota[] getMascotasDisponibles() {return mascotasDisponibles;}
    public void setMascotasDisponibles(int i, Mascota mascotasDisponibles) {this.mascotasDisponibles[i] = mascotasDisponibles;}
    public int getContadorMascotasVivas() {return contadorMascotasVivas;}
    public void setContadorMascotasVivas(int contadorMascotasVivas) {this.contadorMascotasVivas = contadorMascotasVivas;}
    public int getContadorVictorias() {return contadorVictorias;}
    public void setContadorVictorias(int contadorVictorias) {this.contadorVictorias = contadorVictorias;}
}
