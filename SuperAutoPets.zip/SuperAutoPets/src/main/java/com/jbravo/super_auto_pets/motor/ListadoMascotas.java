package com.jbravo.super_auto_pets.motor;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;
import com.jbravo.super_auto_pets.mascotas.tier1.*;
import com.jbravo.super_auto_pets.mascotas.tier2.*;
import com.jbravo.super_auto_pets.mascotas.tier3.*;
import com.jbravo.super_auto_pets.mascotas.tier4.*;
import com.jbravo.super_auto_pets.mascotas.tier5.*;
import com.jbravo.super_auto_pets.mascotas.tier6.*;
import com.jbravo.super_auto_pets.mascotas.tier7.*;

public class ListadoMascotas {
    //retornar una mascota

    public static Mascota tier1(int rango1a8){
        switch (rango1a8){
            case 1:
                return new Hormiga();
            case 2:
                return new Pescado();
            case 3:
                return new Mosquito();
            case 4:
                return new Grillo();
            case 5:
                return new Castor();
            case 6:
                return new Caballo();
            case 7:
                return new Nutria();
            case 8:
                return new Escarabajo();
            default:
                return new MascotaEmpty();
        }
    }

    public static Mascota tier2(int rango1a8){
        switch (rango1a8){
            case 1:
                return new Sapo();
            case 2:
                return new Dodo();
            case 3:
                return new Elefante();
            case 4:
                return new PuercoEspin();
            case 5:
                return new Pavoreal();
            case 6:
                return new Rata();
            case 7:
                return new Zorro();
            case 8:
                return new Arania();
            default:
                return new MascotaEmpty();
        }
    }

    public static Mascota tier3(int rango1a11){
        switch (rango1a11){
            case 1:
                return new Camello();
            case 2:
                return new Mapache();
            case 3:
                return new  Jirafa();
            case 4:
                return new Tortuga();
            case 5:
                return new Caracol();
            case 6:
                return new Oveja();
            case 7:
                return new Conejo();
            case 8:
                return new Lobo();
            case 9:
                return new Buey();
            case 10:
                return new Canguro();
            case 11:
                return new Buho();
            default:
                return new MascotaEmpty();
        }
    }

    public static Mascota tier4(int rango1a8){
        switch (rango1a8){
            case 1:
                return new Venado();
            case 2:
                return new Loro();
            case 3:
                return new Hipopotamo();
            case 4:
                return new Delfin();
            case 5:
                return new Puma();
            case 6:
                return new Ballena();
            case 7:
                return new Ardilla();
            case 8:
                return new Llama();
            default:
                return new MascotaEmpty();
        }
    }

    public static Mascota tier5(int rango1a8){
        switch (rango1a8){
            case 1:
                return new Foca();
            case 2:
                return new Jaguar();
            case 3:
                return new Escorpion();
            case 4:
                return new Rinoceronte();
            case 5:
                return new Mono();
            case 6:
                return new Cocodrilo();
            case 7:
                return new Vaca();
            case 8:
                return new Chompipe();
            default:
                return new MascotaEmpty();
        }
    }

    public static Mascota tier6(int rango1a9){
        switch (rango1a9) {
            case 1:
                return new Panda();
            case 2:
                return new Gato();
            case 3:
                return new Tigre();
            case 4:
                return new Serpiente();
            case 5:
                return new Mamut();
            case 6:
                return new Leopardo();
            case 7:
                return new Gorila();
            case 8:
                return new Pulpo();
            case 9:
                return new Mosca();
            default:
                return new MascotaEmpty();
        }
    }

    public static Mascota tier7(int rango1a2){
        switch (rango1a2){
            case 1:
                return new Quetzal();
            case 2:
                return new Camaleon();
            default:
                return new MascotaEmpty();
        }
    }
}
