package com.jbravo.super_auto_pets.mascotas.tier2;
import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Elefante extends Mascota {
    public Elefante(){
        super.setTier(2);
        super.nombreMascota = "Elefante";
        super.id = 11;

        super.unidadesDeDanio = 3;
        super.unidadesDeVida = 5;
        super.tipos = TiposDeMascotas.mamifero + TiposDeMascotas.separador + TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
