package com.jbravo.super_auto_pets.mascotas.tier1;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Nutria extends Mascota {
    public Nutria(){
        super.setTier(1);
        super.nombreMascota = "Nutria";
        super.id = 7;

        super.unidadesDeDanio = 1;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.mamifero;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }


}
