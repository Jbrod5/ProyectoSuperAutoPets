package com.jbravo.super_auto_pets.mascotas.tier7;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Camaleon extends Mascota {
    public Camaleon() {
        super.setTier(7);
        super.nombreMascota = "Camaleon";
        super.id = 54;

        super.unidadesDeDanio = 8;
        super.unidadesDeVida = 8;
        super.tipos = TiposDeMascotas.reptil + TiposDeMascotas.separador + TiposDeMascotas.solitario;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
