package com.jbravo.super_auto_pets.mascotas.tier1;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;

public class Caballo extends Mascota {
    public Caballo(){
        super.setTier(1);
        super.nombreMascota = "Caballo";
        super.id = 6;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 1;
        super.tipos = TiposDeMascotas.mamifero + TiposDeMascotas.separador + TiposDeMascotas.domestico;
    }

    @Override
    public void efectoAlInicio() {
        for (int i = 0; i<5; i++){
            if (MotorDeJuego.jugadorA.mascotasAPelear[i] instanceof Caballo || MotorDeJuego.jugadorA.mascotasAPelear[i] instanceof MascotaEmpty) {
            } else {
                switch (super.experiencia) {
                    case 1 -> MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeDanio() + 1);
                    case 2 -> MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeDanio() + 2);
                    default -> MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeDanio() + 3);
                }
            }
        }
    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }


}
