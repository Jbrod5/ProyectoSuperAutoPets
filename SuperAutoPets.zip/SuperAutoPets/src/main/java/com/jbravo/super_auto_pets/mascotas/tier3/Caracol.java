package com.jbravo.super_auto_pets.mascotas.tier3;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Caracol extends Mascota {

    public Caracol() {
        super.setTier(3);
        super.nombreMascota = "Caracol";
        super.id = 21;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.insecto + TiposDeMascotas.separador + TiposDeMascotas.solitario;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}