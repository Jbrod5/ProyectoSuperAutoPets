package com.jbravo.super_auto_pets.motor;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;
import com.jbravo.super_auto_pets.powerups.Comida;
import com.jbravo.super_auto_pets.powerups.comida.ComidaEmpty;
import com.jbravo.super_auto_pets.utilidades.LimpiarPantalla;
import com.jbravo.super_auto_pets.powerups.Campo;
import com.jbravo.super_auto_pets.powerups.campos.*;

import java.util.Random;
import java.util.Scanner;

public class Tienda {
    Random random = new Random();
    Scanner scanner = new Scanner(System.in);
    float rebaja;
    int oro; //10 por turno
    int cantidadDeMascotasAVender;
    boolean restriccionLeche;
    boolean boof = false;
    boolean boofRealizado = false;
    Mascota [] mascotasAVender = new Mascota[5]; //cinco es el máximo de mascotas a vender
    Comida [] comidaAVender = new Comida[2];     //dos comidas a vander siempre
    Campo [] campos = new Campo[6];              //Hay 6 campos disponibles

    public Tienda(){for(int i = 0; i<2; i++){ comidaAVender[i] = new ComidaEmpty();}}

    public void setBoof(boolean boof) {this.boof = boof;}

    public void menuTienda() throws CloneNotSupportedException {
        MotorDeJuego.jugadorA.oro = 10;
        MotorDeJuego.jugadorA.cargarEquipo();
        MotorDeJuego.jugadorA.recuperarContadorMascotasVivas();
        generarComida();
        generarMascotas();
        generarCampos();
        String opcion;
        boofRealizado = false;

        do {
            //LimpiarPantalla.limpiarPantalla();
            if(boof){
                if (!boofRealizado){
                    for (int i = 0; i < cantidadDeMascotasAVender; i++) {
                        mascotasAVender[i].setUnidadesDeDanio(mascotasAVender[i].getUnidadesDeDanio() + 2);
                        mascotasAVender[i].setUnidadesDeVida(mascotasAVender[i].getUnidadesDeVida() + 1);
                        boofRealizado = true;
                        System.out.println("Las mascotas de la tienda se han boofeado :3");
                    }
                }else{
                    System.out.println("Las mascotas de la tienda se han boofeado :3");
                }
            }

            MotorDeJuego.jugadorA.cargarEquipo();

            Scanner scanner = new Scanner(System.in);
            System.out.println("\nBIENVENIDO A LA TIENDA");

            mostrarMascotasJugador();
            mostrarMascotasTienda();
            mostrarComidaTienda();

            System.out.println("\n  ¿Qué desea hacer? ");
            System.out.println("1. Comprar mascotas ");
            System.out.println("2. Comprar comida   ");
            System.out.println("3. Ordenar mascotas ");
            System.out.println("4. Fusionar Mascotas");
            System.out.println("5. Vender Mascotas  ");
            System.out.println("6. Seleccionar campo");
            System.out.println("7. ¡A pelear!       ");
            opcion = scanner.nextLine();
            switch (Integer.parseInt(opcion)) {
                case 1:
                    comprarMascotas();
                    break;
                case 2:
                    comprarComida();
                    break;
                case 3:
                    ordenarMascotas();
                    break;
                case 4:
                    fusionarMascotas();
                    break;
                case 5:
                    venderMascotas();
                    break;
                case 6:
                    seleccionarCampo();
            }
        }while (!opcion.equals("7"));
    }

    public void generarMascotas(){
        for(int i = 0; i < 5; i++){
            mascotasAVender[i] = new MascotaEmpty();
        }
        if (ModoDeJuego.contadorRonda <=3 && ModoDeJuego.contadorRonda >0){ //solo tres mascotas
            cantidadDeMascotasAVender = 3; }
        if( ModoDeJuego.contadorRonda >3 && ModoDeJuego.contadorRonda<=6){ //vender cuatro mascotas
            cantidadDeMascotasAVender = 4; }
        if (ModoDeJuego.contadorRonda >= 7){ //vender cinco mascotas
            cantidadDeMascotasAVender = 5; }

        switch (ModoDeJuego.tier) {
            case 1: for (int i = 0; i < cantidadDeMascotasAVender; i++) {
                mascotasAVender[i] = ListadoMascotas.tier1(random.nextInt(8) + 1);}
                break;
            case 2: for (int i = 0; i < cantidadDeMascotasAVender; i++) {
                mascotasAVender[i] = ListadoMascotas.tier2(random.nextInt(8) + 1);}
                break;
            case 3: for (int i = 0; i < cantidadDeMascotasAVender; i++) {
                mascotasAVender[i] = ListadoMascotas.tier3(random.nextInt(11) + 1);}
                break;
            case 4: for (int i = 0; i < cantidadDeMascotasAVender; i++) {
                mascotasAVender[i] = ListadoMascotas.tier4(random.nextInt(8) + 1);}
                break;
            case 5: for (int i = 0; i < cantidadDeMascotasAVender; i++) {
                mascotasAVender[i] = ListadoMascotas.tier5(random.nextInt(8) + 1);}
                break;
            case 6: for (int i = 0; i < cantidadDeMascotasAVender; i++) {
                mascotasAVender[i] = ListadoMascotas.tier6(random.nextInt(9) + 1);}
                break;
            case 7: for (int i = 0; i < cantidadDeMascotasAVender; i++) {
                mascotasAVender[i] = ListadoMascotas.tier7(random.nextInt(2) + 1);}
                break;
        }
    }
    public void generarComida(){
        switch(ModoDeJuego.tier){
            case 1: for (int i = 0; i < 2; i++) {
                comidaAVender[i] = ListadoComidas.tier1(random.nextInt(3) + 1);}
                break;
            case 2: for (int i = 0; i < 2; i++) {
                comidaAVender[i] = ListadoComidas.tier2(random.nextInt(4) + 1);}
                break;
            case 3:for (int i = 0; i < 2; i++) {
                comidaAVender[i] = ListadoComidas.tier3(random.nextInt(6) + 1);}
                break;
            case 4: for (int i = 0; i < 2; i++) {
                comidaAVender[i] = ListadoComidas.tier4(random.nextInt(6) + 1);}
                break;
            case 5: for (int i = 0; i < 2; i++) {
                comidaAVender[i] = ListadoComidas.tier5(random.nextInt(3) + 1);}
                break;
            case 6: for (int i = 0; i < 2; i++) {
                comidaAVender[i] = ListadoComidas.tier6(random.nextInt(3) + 1);}
                break;
            default: for (int i = 0; i < 2; i++) {
                comidaAVender[i] = ListadoComidas.tier7(random.nextInt(3) + 1);}
                break;
        }
    }
    public void generarCampos(){
        campos[0] = new SinCampo ();
        campos[1] = new Pantano  ();
        campos[2] = new Nubes    ();
        campos[3] = new Mar      ();
        campos[4] = new Bosque   ();
        campos[5] = new Granja   ();
    }

    public void comprarMascotas(){ //el precio de las mascotas siempre es de 3 de oro
        boolean espacio = true;
        String posicionInsertar;
        String posicionTienda;
        for (int i = 0; i<5; i++){//verificar si hay espacios en el equipo para comprar
            if(MotorDeJuego.jugadorA.mascotasDisponibles[i] instanceof MascotaEmpty){
                espacio = true; break; }else { espacio = false;} }

        if (espacio){
            System.out.println("Oro disponible: " + MotorDeJuego.jugadorA.oro);
            System.out.println("Ingrese la posicion de las mascotas disponibles en tienda que desea comprar");
            posicionTienda = scanner.nextLine();
            if((mascotasAVender[Integer.parseInt(posicionTienda)-1] instanceof MascotaEmpty || (Integer.parseInt(posicionTienda)-1)<0) || (Integer.parseInt(posicionTienda)-1)>=5){
                System.out.println("La posicion ingresada no es valida");
            }else{
                System.out.println("Ingrese la posicion en su equipo para colocar la nueva mascota");
                posicionInsertar = scanner.nextLine();
                if(MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionInsertar)-1] instanceof MascotaEmpty){
                    if((MotorDeJuego.jugadorA.oro - 3) > 0) {
                        //guarda la mascota de la tienda en el equipo no destructivo y en el destructivo
                        MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionInsertar) - 1] = mascotasAVender[Integer.parseInt(posicionTienda) - 1];
                        MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionInsertar) - 1] = mascotasAVender[Integer.parseInt(posicionTienda) - 1];
                        mascotasAVender[Integer.parseInt(posicionTienda) - 1] = new MascotaEmpty();
                        MotorDeJuego.jugadorA.oro = MotorDeJuego.jugadorA.oro - 3;
                        System.out.println("¡Compra realizada correctamente!");
                        MotorDeJuego.jugadorA.contadorMascotasVivas = MotorDeJuego.jugadorA.contadorMascotasVivas + 1;
                    }else {
                        System.out.println("No tiene suficiente dinero para comprar esta mascota");
                    }
                }else{
                    System.out.println("No puede colocar una mascota en esa posicion");
                }
            }
        }else {
            System.out.println("No tiene espacios disponibles en su equipo para comprar una mascota");
        }
    }
    public void venderMascotas(){
        System.out.println("Oro disponible: " + MotorDeJuego.jugadorA.oro);
        String opcionVenta;
        System.out.println("Este es su equipo actual: ");
        mostrarMascotasJugador();
        System.out.println("Por favor ingrese la posicion de su equipo que desea vender");
        System.out.println("Tome en cuenta que el oro que recibirá por cada compra es igual al nivel de la mascota que quiere vender");
        opcionVenta = scanner.nextLine();
        if((Integer.parseInt(opcionVenta)-1) < 0 || (Integer.parseInt(opcionVenta)-1) > 5){
            System.out.println("Posicion Invalida");
        }else{
            if(MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(opcionVenta)-1].getExperiencia() > 3){
                MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(opcionVenta)-1].setExperiencia(3); //definir su experiencia como 3 para agregar oro
            }
            MotorDeJuego.jugadorA.oro = MotorDeJuego.jugadorA.oro +  MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(opcionVenta)-1].getExperiencia();
            MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(opcionVenta)-1] = new MascotaEmpty();
            MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(opcionVenta)-1] = new MascotaEmpty();
            System.out.println("¡Venta completada exitosamaente!");
            MotorDeJuego.jugadorA.contadorMascotasVivas = MotorDeJuego.jugadorA.contadorMascotasVivas - 1;
        }

    }
    public void comprarComida(){
        String posicionComida;
        String posicionMascota;

        if(MotorDeJuego.jugadorA.oro - 3 >= 0) {
            System.out.println("Oro disponible: " + MotorDeJuego.jugadorA.oro);
            System.out.println("Por favor ingrese la posicion de la comida que desea comprar");
            posicionComida = scanner.nextLine();
            System.out.println("Por favor ingrese la posicion de la mascota que va a recibir la comida");
            posicionMascota = scanner.nextLine();

            if(Integer.parseInt(posicionComida) - 1 < 0 || Integer.parseInt(posicionComida) - 1 > 1 || Integer.parseInt(posicionMascota)-1 <0 || Integer.parseInt(posicionMascota) - 1 > 4  || comidaAVender[Integer.parseInt(posicionComida) - 1] instanceof ComidaEmpty){
                System.out.println("Una o ambas posiciones no son validas :c");
            }else{
                if(comidaAVender[Integer.parseInt(posicionComida)-1].isEfecto()){
                    if(MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionMascota)-1].getComida() instanceof ComidaEmpty){
                        //cargar la comida en mascotas destructiva y no destructiva
                        MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionMascota)-1].setComida(comidaAVender[Integer.parseInt(posicionComida)-1]);
                        MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionMascota)-1].setComida(comidaAVender[Integer.parseInt(posicionComida)-1]);
                        comidaAVender[Integer.parseInt(posicionComida)-1] = new ComidaEmpty();
                        MotorDeJuego.jugadorA.oro = MotorDeJuego.jugadorA.oro - 3;
                        //ejecutar cualquier cambio que pueda hacerle a la mascota
                        MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionMascota)-1].getComida().cambioMascota(Integer.parseInt(posicionMascota)-1);
                    /**/MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionMascota)-1].getComida().cambioMascota(Integer.parseInt(posicionMascota)-1);
                        System.out.println("¡Compra realizada correctamente!");
                    }else{
                        System.out.println("No procede, esta mascota ya tiene una comida de tipo efecto :c");
                    }
                }else{//comidas que solo realizan cambios a la mascota
                    comidaAVender[Integer.parseInt(posicionComida)-1].cambioMascota(Integer.parseInt(posicionMascota)-1);
                    comidaAVender[Integer.parseInt(posicionComida)-1] = new ComidaEmpty();
                    MotorDeJuego.jugadorA.oro = MotorDeJuego.jugadorA.oro - 3;

                    System.out.println("las nuevas stats de la mascota son las siguientes: ");
                    System.out.println("mascota pelear:");
                    System.out.println(MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionMascota)-1].getInfo());
                    System.out.println("mascota inmutable");
                    System.out.println(MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionMascota)-1].getInfo());

                }
            }
        }else{
            System.out.println("No tiene suficiente oro para comprar comida :'c");
        }
    }

    public void ordenarMascotas(){
        String opcion;
        System.out.println("Por favor especifique la forma de ordenar que desea");
        System.out.println("De manera arbitraria ---------------------------- 1");
        System.out.println("Por TIER (ascendente) --------------------------- 2");
        System.out.println("Por TIER (descendente) -------------------------- 3");
        System.out.println("Por vida (ascendente) --------------------------- 4");
        System.out.println("Por vida (descendente) -------------------------- 5");
        System.out.println("Por danio (ascendente) -------------------------- 6");
        System.out.println("por danio (descendente) ------------------------- 7");
        opcion = scanner.nextLine();
        switch (opcion){
            case "1":
                MotorDeJuego.jugadorA.ordenarMascotasArbitrario();
                break;
            case "2":
                MotorDeJuego.jugadorA.ordenarMascotasPorTier(false);
                break;
            case "3":
                MotorDeJuego.jugadorA.ordenarMascotasPorTier(true);
                break;
            case "4":
                MotorDeJuego.jugadorA.ordenarMascotasPorVida(false);
                break;
            case "5":
                MotorDeJuego.jugadorA.ordenarMascotasPorVida(true);
                break;
            case "6":
                MotorDeJuego.jugadorA.ordenarMascotasPorDanio(false);
                break;
            case "7":
                MotorDeJuego.jugadorA.ordenarMascotasPorDanio(true);
                break;
        }

    }

    public void fusionarMascotas(){
        String posicionEquipo;
        String posicionTienda;

        System.out.println("Oro disponible: " + MotorDeJuego.jugadorA.oro);

        if(MotorDeJuego.jugadorA.oro >=3){ //comprueba si hay suficiente oro para comprar la mascota a fusionar
            System.out.println("Por favor ingrese la mascota de su equipo que desea fusionar");
            posicionEquipo = scanner.nextLine();
            System.out.println("Por favor ingrese la mascota de la tienda que desea fusionar");
            posicionTienda = scanner.nextLine();

            if ((((Integer.parseInt(posicionTienda) - 1) < 0 || Integer.parseInt(posicionEquipo) - 1 < 0)) || (((Integer.parseInt(posicionTienda) - 1) > 5 || Integer.parseInt(posicionEquipo) - 1 > 5))) {
                System.out.println("No se puede hacer la fusión, una o ambas posiciones son invalidas");
            } else {
                //compara si los tipos de mascotas son iguales
                if (MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionEquipo)-1].getNombreMascota().equals(mascotasAVender[Integer.parseInt(posicionTienda)-1].getNombreMascota())) {
                    if (MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionEquipo)-1].getExperiencia() < 2) { //porque el nivel máximo es 3
                       //Afectar a la mascota en el equipo destructivo y no destructivo
                        MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionEquipo)-1].setExperiencia(MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionEquipo)-1].getExperiencia() + 1);
                        MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionEquipo)-1].setExperiencia(MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionEquipo)-1].getExperiencia() + 1);
                    }
                    //Estadisticas basicas son: ataque - vida || Sumar +1 en esas estadísticas
                    MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionEquipo)-1].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionEquipo)-1].getUnidadesDeDanio() + 1);
                    MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionEquipo)-1].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasDisponibles[Integer.parseInt(posicionEquipo)-1].getUnidadesDeVida() + 1);
                    //afectar también el equipo destructivo
                    MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionEquipo)-1].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionEquipo)-1].getUnidadesDeDanio() + 1);
                    MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionEquipo)-1].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[Integer.parseInt(posicionEquipo)-1].getUnidadesDeVida() + 1);

                    MotorDeJuego.jugadorA.oro = MotorDeJuego.jugadorA.oro - 3;
                    mascotasAVender[Integer.parseInt(posicionTienda)-1] = new MascotaEmpty();
                    System.out.println("¡Fusion completada exitosamente!");
                }else{
                    System.out.println("Las mascotas seleccionadas no son compatibles :c");
                }
            }
        }else {
            System.out.println("No tiene suficiente oro para comprar una mascota");
        }

    }

    public void mostrarMascotasTienda(){
        System.out.println("Estas son las mascotas disponibles en la tienda :3");
        for(int i = 0; i < cantidadDeMascotasAVender; i++){
            System.out.println((i+1)+". " + mascotasAVender[i].getInfo());
        }
        System.out.println("\n --------------------------------------------------------------");
    }
    public void mostrarComidaTienda(){
        System.out.println("Esta es la comida disponible en la tienda :3");
        for(int i = 0; i < 2; i++){
            System.out.println( (i+1) + ". " + comidaAVender[i].getInfo());
        }
        System.out.println("\n --------------------------------------------------------------");
    }
    public void mostrarMascotasJugador(){
        System.out.println("Este es su equipo actualmente :3");
        for (int i = 0; i < 5; i++) {
            System.out.println((i + 1) + ". " + MotorDeJuego.jugadorA.mascotasDisponibles[i].getInfo());
        }
        System.out.println("\n --------------------------------------------------------------");
    }
    public void seleccionarCampo(){
        String opcion;
        System.out.println("    Ingrese el campo que desea    ");
        System.out.println("Estos son los campos disponibles: ");
        for (int i = 0; i<6; i++){
            System.out.println((i+1) + campos[i].getInfo());
        }
        opcion = scanner.nextLine();
        if(Integer.parseInt(opcion)-1 >= 0 && Integer.parseInt(opcion)-1<5){
            ModoDeJuego.campo = campos[Integer.parseInt(opcion)-1];
        }else{
            System.out.println("La posicion del campo ingresada no es valida");
        }

    }

}