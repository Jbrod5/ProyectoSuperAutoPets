package com.jbravo.super_auto_pets.mascotas.tier1;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Escarabajo extends Mascota {
    public Escarabajo(){
        super.setTier(1);
        super.nombreMascota = "Escarabajo";
        super.id = 8;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 3;
        super.tipos = TiposDeMascotas.insecto;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }

}
