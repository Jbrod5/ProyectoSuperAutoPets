package com.jbravo.super_auto_pets.powerups.comida.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Hongo extends Comida {

    public Hongo(){
        super.setNombre("Hongo");
        super.setEfecto(true);
        super.setDescripcion(" Es tipo efecto, Da 1 vida extra al animal solo que sale con 1 de vida y 1 de daño");
    }

    @Override
    public void cambioMascota(int posicionMascota){
        MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setVidaExtra(true);
        MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].setVidaExtra(true);
    }

    @Override
    public void efectoAlMorir(int posicionMascota){
        if(MotorDeJuego.jugadorA.mascotasAPelear[0].isVidaExtra()) {
            System.out.println("Jeje " + MotorDeJuego.jugadorA.mascotasAPelear[0].getNombreMascota() + " tiene una vida extra");
            MotorDeJuego.jugadorA.mascotasAPelear[0].setUnidadesDeVida(1);
            MotorDeJuego.jugadorA.mascotasAPelear[0].setUnidadesDeDanio(1);
            MotorDeJuego.jugadorA.mascotasAPelear[0].setVidaExtra(false);
        }
    }
}
