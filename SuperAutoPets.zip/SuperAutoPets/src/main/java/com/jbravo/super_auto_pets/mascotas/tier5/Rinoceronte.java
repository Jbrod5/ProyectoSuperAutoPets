package com.jbravo.super_auto_pets.mascotas.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Rinoceronte extends Mascota {
    public Rinoceronte() {
        super.setTier(5);
        super.nombreMascota = "Rinoceronte";
        super.id = 39;

        super.unidadesDeDanio = 5;
        super.unidadesDeVida = 8;
        super.tipos = TiposDeMascotas.desertico + TiposDeMascotas.separador + TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
