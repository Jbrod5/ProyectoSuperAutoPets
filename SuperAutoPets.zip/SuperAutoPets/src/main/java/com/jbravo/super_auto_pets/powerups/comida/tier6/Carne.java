package com.jbravo.super_auto_pets.powerups.comida.tier6;

import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Carne extends Comida {
    public Carne(){
        super.setNombre("Carne");
        super.setEfecto(true);
        super.setDescripcion(" Es tipo efecto, y hace que el animal que lo porté haga 20 de daño adicional una vez por ronda");
    }

    @Override
    public void cambioMascota(int posicionMascota){
        MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setCarne(true);
        MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].setCarne(true);
    }

}
