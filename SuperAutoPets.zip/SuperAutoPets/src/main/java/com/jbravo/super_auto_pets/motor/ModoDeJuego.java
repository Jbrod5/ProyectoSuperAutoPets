package com.jbravo.super_auto_pets.motor;

import com.jbravo.super_auto_pets.mascotas.tier4.Ardilla;
import com.jbravo.super_auto_pets.powerups.Campo;
import com.jbravo.super_auto_pets.powerups.campos.*;

public class ModoDeJuego {
    //Los jugadores están en Motor (motor está por encima de modo de juego)
    protected static int contadorRonda = 0;
    protected static int tier = 0;
    protected static Tienda tienda = new Tienda();
    protected static Campo campo = new SinCampo();
    protected static Batalla batalla = new Batalla();

    public static int getContadorRonda() {
        return contadorRonda;
    }

    public void Juego() throws CloneNotSupportedException {

        do {
            contadorRonda ++;
            calcularTier();
            tienda.menuTienda();
            MotorDeJuego.jugadorB.generarMascotas();
            batalla.iniciarBatalla();
        }while (MotorDeJuego.jugadorA.vida != 0 && MotorDeJuego.jugadorB.vida != 0);

        if(MotorDeJuego.jugadorA.vida == 0){
            System.out.println("\n Has perdido el juego :c \n ¡SUERTE A LA PROXIMA!");
        }else{
            System.out.println("\n Has ganado el juego :D \n ¡FELICIDADES! ");
        }
    }

    public void calcularTier(){
        if(contadorRonda==1){
            tier = 1;
        } if(contadorRonda >=2){
            tier = 2;
        } if(contadorRonda>=4){
            tier = 3;
        } if(contadorRonda>=6){
            tier = 4;
        } if(contadorRonda>=8){
            tier = 5;
        } if(contadorRonda>=10){
            tier = 6;
        } if(contadorRonda>=12){
            tier = 7;}
    }

    public static Tienda getTienda() {return tienda;}
    public static void setTienda(Tienda tienda) {ModoDeJuego.tienda = tienda;}
}
