package com.jbravo.super_auto_pets.mascotas.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Jaguar extends Mascota {
    public Jaguar() {
        super.setTier(5);
        super.nombreMascota = "Jaguar";
        super.id = 37;

        super.unidadesDeDanio = 7;
        super.unidadesDeVida = 4;
        super.tipos = TiposDeMascotas.mamifero + TiposDeMascotas.separador + TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
