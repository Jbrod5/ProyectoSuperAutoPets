package com.jbravo.super_auto_pets.mascotas.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Mono extends Mascota {

    public Mono() {
        super.setTier(5);
        super.nombreMascota = "Mono";
        super.id = 40;

        super.unidadesDeDanio = 1;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.mamifero;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
