package com.jbravo.super_auto_pets.mascotas.tier2;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Rata extends Mascota {
    public Rata(){
        super.setTier(2);
        super.nombreMascota = "Rata";
        super.id = 14;

        super.unidadesDeDanio = 4;
        super.unidadesDeVida = 5;
        super.tipos = TiposDeMascotas.terrestre + TiposDeMascotas.separador + TiposDeMascotas.solitario;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {

        super.comida.efectoAlMorir(0);
    }
}
