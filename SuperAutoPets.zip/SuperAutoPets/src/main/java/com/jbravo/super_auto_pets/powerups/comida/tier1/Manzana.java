package com.jbravo.super_auto_pets.powerups.comida.tier1;

import com.jbravo.super_auto_pets.motor.Jugador;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Manzana extends Comida {

    public Manzana(){
        super.setNombre("Manzana");
        super.setEfecto(false);
        super.setDescripcion(" Da 1 de vida y 1 de daño a un animal seleccionado");
    }

    @Override
    public void cambioMascota(int posicionMascota){
        MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].getUnidadesDeDanio()+1);
        MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].getUnidadesDeVida()+1);

        MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].getUnidadesDeDanio()+1);
        MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].getUnidadesDeVida()+1);


    }
}
