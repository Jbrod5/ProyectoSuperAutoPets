package com.jbravo.super_auto_pets.utilidades;
import java.util.ArrayList;

public class LimpiarPantalla {

    public static void limpiarPantalla() {
        try {
            String OS = System.getProperty("os.name");
            ArrayList<String> comando = new ArrayList<String>();
            if (OS.contains("Windows")) { //Si es windows ejecutar cls
                comando.add("cmd");
                comando.add("/C");
                comando.add("cls");
            } else {
                comando.add("clear"); //Si no es windows ejecutar clear
            }
            ProcessBuilder pb = new ProcessBuilder(comando);
            Process iniciarProceso = pb.inheritIO().start();
            iniciarProceso.waitFor();
        } catch (Exception e) {
            System.err.println("Error al limpiar pantalla " + e.getMessage());
        }
    }
}
