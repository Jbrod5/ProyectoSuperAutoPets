package com.jbravo.super_auto_pets.powerups.comida.tier3;

import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Pera extends Comida {
    public Pera(){
        super.setNombre("Pera");
        super.setDescripcion(" Le da a un animal que se escoja 2 de vida y 2 de daño");
    }

     @Override
     public void cambioMascota(int posicionMascota){
         MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].getUnidadesDeDanio()+2);
         MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].getUnidadesDeVida()+2);

         MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].getUnidadesDeDanio()+2);
         MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].getUnidadesDeVida()+2);
     }
}
