package com.jbravo.super_auto_pets.powerups.campos;

import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Campo;

public class Pantano extends Campo {

    public Pantano(){
        super.setNombre("Pantano");
        super.setInfo("Los animales tipo reptil ganarán (+1/+1) por cada animal reptil en batalla");
    }

    @Override
    public void bonificacionCampo() {
        int contadorReptil = 0;
        for (int i = 0; i < 5; i++){
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.reptil)){
                contadorReptil++;
            }
        }
        for (int i = 0; i < 5; i++){ //sumar +1 por cada animal de tipo reptil en el equipo
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.reptil)){
                MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeDanio()+contadorReptil);
                MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeVida()+contadorReptil);
            }
        }
    }
}
