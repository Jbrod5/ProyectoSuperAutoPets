package com.jbravo.super_auto_pets.mascotas.tier3;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Lobo extends Mascota {
    public Lobo() {
        super.setTier(3);
        super.nombreMascota = "Lobo";
        super.id = 24;

        super.unidadesDeDanio = 3;
        super.unidadesDeVida = 4;
        super.tipos = TiposDeMascotas.solitario + TiposDeMascotas.separador + TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}