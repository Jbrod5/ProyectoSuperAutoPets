package com.jbravo.super_auto_pets.mascotas.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Chompipe extends Mascota {
    public Chompipe() {
        super.setTier(5);
        super.nombreMascota = "Chompipe";
        super.id = 43;

        super.unidadesDeDanio = 3;
        super.unidadesDeVida = 4;
        super.tipos = TiposDeMascotas.terrestre + TiposDeMascotas.separador + TiposDeMascotas.volador;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
