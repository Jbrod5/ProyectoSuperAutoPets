package com.jbravo.super_auto_pets.mascotas.tier6;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Mosca extends Mascota {
    public Mosca() {
        super.setTier(6);
        super.nombreMascota = "Mosca";
        super.id = 52;

        super.unidadesDeDanio = 5;
        super.unidadesDeVida = 5;
        super.tipos = TiposDeMascotas.volador + TiposDeMascotas.separador + TiposDeMascotas.insecto;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
