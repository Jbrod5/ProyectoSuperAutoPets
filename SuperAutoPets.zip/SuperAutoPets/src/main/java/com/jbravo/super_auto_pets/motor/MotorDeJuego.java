package com.jbravo.super_auto_pets.motor;

public class MotorDeJuego {
    public static Jugador jugadorA = new Jugador();
    public static Bot jugadorB = new Bot();

    public static ModoDeJuego modoa = new ModoDeJuego();

    public MotorDeJuego(){


    }
}
