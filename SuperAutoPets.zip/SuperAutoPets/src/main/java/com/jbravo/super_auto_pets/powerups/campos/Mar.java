package com.jbravo.super_auto_pets.powerups.campos;

import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Campo;

public class Mar extends Campo {

    public Mar(){
        super.setNombre("Campo");
        super.setInfo("Los animales de tipo acuático ganarán (+1/+1) por cada animal acuático en batalla");
    }

    @Override
    public void bonificacionCampo() {
        int contadorAcuatico = 0;
        for (int i = 0; i < 5; i++){
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.acuatico)){
                contadorAcuatico++;
            }
        }
        for (int i = 0; i < 5; i++){ //sumar +1 por cada animal de tipo acuatico en el equipo
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.acuatico)){
                MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeDanio()+contadorAcuatico);
                MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeVida()+contadorAcuatico);
            }
        }
    }
}
