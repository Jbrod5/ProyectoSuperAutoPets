package com.jbravo.super_auto_pets.mascotas.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Cocodrilo extends Mascota {
    public Cocodrilo() {
        super.setTier(5);
        super.nombreMascota = "Cocodrilo";
        super.id = 41;

        super.unidadesDeDanio = 8;
        super.unidadesDeVida = 4;
        super.tipos = TiposDeMascotas.reptil + TiposDeMascotas.separador + TiposDeMascotas.solitario;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
