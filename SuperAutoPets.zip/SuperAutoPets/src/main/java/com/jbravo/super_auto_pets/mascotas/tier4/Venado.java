package com.jbravo.super_auto_pets.mascotas.tier4;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Venado extends Mascota {
    public Venado() {
        super.setTier(4);
        super.nombreMascota = "Venado";
        super.id = 28;

        super.unidadesDeDanio = 1;
        super.unidadesDeVida = 1;
        super.tipos = TiposDeMascotas.mamifero;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}