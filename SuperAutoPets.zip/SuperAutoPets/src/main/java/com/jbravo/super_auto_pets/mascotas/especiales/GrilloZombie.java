package com.jbravo.super_auto_pets.mascotas.especiales;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.powerups.Comida;

public class GrilloZombie extends Mascota {


    public GrilloZombie (int experiencia, Comida objeto){
        super.setTier(1);
        super.nombreMascota = "Grillo Zombie";
        super.id = 0;

        super.unidadesDeDanio = experiencia;
        super.unidadesDeVida = experiencia;
        super.tipos = TiposDeMascotas.insecto;
        super.comida = objeto;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        comida.efectoAlMorir(0);
    }
}
