package com.jbravo.super_auto_pets.powerups.campos;

import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Campo;

public class Nubes extends Campo {

    public Nubes(){
        super.setNombre("Nubes");
        super.setInfo("Los animales tipo volador ganarán (+1/+1) por cada animal volador en batalla");
    }

    @Override
    public void bonificacionCampo() {
        int contadorVolador = 0;
        for (int i = 0; i < 5; i++){
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.volador)){
                contadorVolador++;
            }
        }
        for (int i = 0; i < 5; i++){ //sumar +1 por cada animal de tipo volador en el equipo
            if(MotorDeJuego.jugadorA.mascotasAPelear[i].getTipos().contains(TiposDeMascotas.volador)){
                MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeDanio()+contadorVolador);
                MotorDeJuego.jugadorA.mascotasAPelear[i].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[i].getUnidadesDeVida()+contadorVolador);
            }
        }
    }
}
