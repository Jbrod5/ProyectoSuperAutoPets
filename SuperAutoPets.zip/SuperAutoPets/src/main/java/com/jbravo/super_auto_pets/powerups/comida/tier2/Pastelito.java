package com.jbravo.super_auto_pets.powerups.comida.tier2;

import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Pastelito extends Comida {
    public Pastelito(){
        super.setUnSoloUso(true);
        super.setNombre("Pastelito");
        super.setDescripcion(" Da 3 de vida y 3 de daño solo por la siguiente ronda de pelea.");
    }

    @Override
    public void cambioMascota(int posicionMascota){
        MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].getUnidadesDeVida()+3);
        MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].getUnidadesDeDanio()+3);
    }
}
