package com.jbravo.super_auto_pets.mascotas.tier3;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Oveja extends Mascota {
    public Oveja() {
        super.setTier(3);
        super.nombreMascota = "Oveja";
        super.id = 22;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.domestico + TiposDeMascotas.separador + TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}