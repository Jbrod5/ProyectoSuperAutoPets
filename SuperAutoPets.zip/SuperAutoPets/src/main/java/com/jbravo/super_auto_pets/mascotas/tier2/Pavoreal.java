package com.jbravo.super_auto_pets.mascotas.tier2;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Pavoreal extends Mascota {
    public Pavoreal(){
        super.setTier(2);
        super.nombreMascota = "Pavoreal";
        super.id = 13;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 5;
        super.tipos = TiposDeMascotas.domestico + TiposDeMascotas.separador+ TiposDeMascotas.volador;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
