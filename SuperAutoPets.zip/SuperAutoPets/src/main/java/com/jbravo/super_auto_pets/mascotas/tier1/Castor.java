package com.jbravo.super_auto_pets.mascotas.tier1;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Castor extends Mascota {
    public Castor(){
        super.setTier(1);
        super.nombreMascota = "Castor";
        super.id = 5;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.terrestre + TiposDeMascotas.separador + TiposDeMascotas.acuatico;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }


}
