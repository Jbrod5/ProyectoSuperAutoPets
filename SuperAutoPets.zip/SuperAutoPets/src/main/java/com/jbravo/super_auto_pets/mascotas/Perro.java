package com.jbravo.super_auto_pets.mascotas;

public  class Perro extends Mascota{

    public Perro(){
        super.setTier(5);
        super.nombreMascota = "Perro";
        super.unidadesDeDanio = 10;
        super.unidadesDeVida = 10;
    }

    @Override
    public void efectoAlInicio() {
        System.out.println("Esta es otra mascota y tiene el tier: "+ super.getTier());
        System.out.println("soy un perro jsjsjs");
    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {

    }
}
