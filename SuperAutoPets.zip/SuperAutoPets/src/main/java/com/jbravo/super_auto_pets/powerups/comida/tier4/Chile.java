package com.jbravo.super_auto_pets.powerups.comida.tier4;

import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Chile extends Comida {

    public Chile(){
        super.setNombre("Chile");
        super.setEfecto(true);
        super.setDescripcion(" Es tipo efecto, y hace que el animal que lo porta haga 5 de daño al animal que se encuentra detrás del que atacó");
    }

    @Override
    public void efectoAlRecibirDanio(int posicionMascota){
        //5 de danio al animal que se encuentre detrás del que atacó (o sea la posición 1 en el array ya que 0 es quien ataca)
        if(MotorDeJuego.jugadorB.mascotasAPelear[1] instanceof MascotaEmpty){
            System.out.println("No hay una mascota que reciba el chile >:c");
        }else{
            MotorDeJuego.jugadorB.mascotasDisponibles[1].recibirDanio(5);
        }
    }
}
