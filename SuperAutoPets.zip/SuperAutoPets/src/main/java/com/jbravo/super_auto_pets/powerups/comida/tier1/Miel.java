package com.jbravo.super_auto_pets.powerups.comida.tier1;

import com.jbravo.super_auto_pets.mascotas.especiales.Abeja;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Miel extends Comida {
    public Miel() {
        super.setNombre("Miel");
        super.setEfecto(true);
        super.setDescripcion("Es tipo efecto, donde hace que durante las rondas de pelea, cuando se muera \n la mascota que se le dió, invoca una abeja que tiene 1 de vida y 1 de daño");
    }

    @Override
    public void efectoAlMorir(int posicionMascota) {
        MotorDeJuego.jugadorA.mascotasAPelear[0] = new Abeja();
    }
}
