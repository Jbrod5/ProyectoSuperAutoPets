package com.jbravo.super_auto_pets.mascotas.tier4;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Loro extends Mascota {
    public Loro() {
        super.setTier(4);
        super.nombreMascota = "Loro";
        super.id = 29;

        super.unidadesDeDanio = 5;
        super.unidadesDeVida = 3;
        super.tipos = TiposDeMascotas.volador;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
