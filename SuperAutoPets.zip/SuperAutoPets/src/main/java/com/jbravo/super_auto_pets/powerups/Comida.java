package com.jbravo.super_auto_pets.powerups;

public abstract class Comida {

    private boolean efecto = false;
    private int efect = 0; //0 para no, 1 para si
    private boolean unSoloUso = false; //comprobar si es de un solo uso para guardar en equipo destructivo o no destructivo
    private boolean random = false; //indica si se debe enviar a un jugador random
    private String nombre;
    private String Descripcion;

    //los temporales que solo duran una partida pueden cargarse directamente al equipo de pelea (destructivo)
    //Así a la siguiente ronda no se verán afectados las mascotas por el mismo efecto

    //Getters y setters

    /*
    public int getEfect() {return efect;}

    public void setEfect(int efect) {Comida.efect = efect;}

    public boolean isEfecto() {return efecto;}
    public void setEfecto(boolean efecto) {this.efecto = efecto;}
    public boolean isUnSoloUso() {return unSoloUso;}
    public void setUnSoloUso(boolean unSoloUso) {this.unSoloUso = unSoloUso;}
    public String getNombre() {return nombre;}
    public void setNombre(String nombre) {this.nombre = nombre;}
    public boolean isRandom() {return random;}
    public void setRandom(boolean random) {this.random = random;}
*/

    public boolean isEfecto() {
        return efecto;
    }

    public void setEfecto(boolean efecto) {
        this.efecto = efecto;
    }

    public int getEfect() {
        return efect;
    }

    public void setEfect(int efect) {
        this.efect = efect;
    }

    public boolean isUnSoloUso() {
        return unSoloUso;
    }

    public void setUnSoloUso(boolean unSoloUso) {
        this.unSoloUso = unSoloUso;
    }

    public boolean isRandom() {
        return random;
    }

    public void setRandom(boolean random) {
        this.random = random;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        Descripcion = descripcion;
    }

    public String getInfo(){ return nombre + " \n  " + Descripcion; }

    public void efectoAlRecibirDanio(int posicionMascota){}
    public void efectoAlMorir(int posicionMascota){}
    public void cambioMascota(int posicionMascota){}
    public void cambioRandom(int posicionMascota){} //cambia pripiedades de la mascota cuuando se compra



}
