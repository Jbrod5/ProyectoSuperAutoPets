package com.jbravo.super_auto_pets.mascotas.tier1;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;

import java.util.Random;

public class Hormiga extends Mascota {

        public Hormiga() {
            super.tier = 1;
            super.setTier(1); //hacen lo mismo, lo importante es que super sirve para hacer referencia a la clase superior/padre
            super.nombreMascota = "Hormiga";
            super.id = 1;

            super.unidadesDeDanio = 2;
            super.unidadesDeVida = 1;
            super.tipos = TiposDeMascotas.insecto + TiposDeMascotas.separador + TiposDeMascotas.terrestre;
        }

        //------------------------------------- EFECTOS --------------------------------------
        @Override
        public void efectoAlInicio() {

        }

        @Override
        public void efectoEnTurno() {

        }

        @Override
        public void efectoAlSubirDeNivel() {

        }

        @Override
        public void efectoAlMorir() {
            Random random = new Random();
            int opcion;
            do {
                opcion = random.nextInt(5);
            }while (MotorDeJuego.jugadorA.mascotasAPelear[opcion] instanceof MascotaEmpty);

            switch (super.experiencia) {
                case 1 -> {
                    MotorDeJuego.jugadorA.mascotasAPelear[opcion].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[opcion].getUnidadesDeDanio() + 2);
                    MotorDeJuego.jugadorA.mascotasAPelear[opcion].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[opcion].getUnidadesDeVida() + 1);
                }
                case 2 -> {
                    MotorDeJuego.jugadorA.mascotasAPelear[opcion].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[opcion].getUnidadesDeDanio() + 4);
                    MotorDeJuego.jugadorA.mascotasAPelear[opcion].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[opcion].getUnidadesDeVida() + 2);
                }
                default -> {
                    MotorDeJuego.jugadorA.mascotasAPelear[opcion].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[opcion].getUnidadesDeDanio() + 6);
                    MotorDeJuego.jugadorA.mascotasAPelear[opcion].setUnidadesDeVida(MotorDeJuego.jugadorA.mascotasAPelear[opcion].getUnidadesDeVida() + 3);
                }
            }
            super.comida.efectoAlMorir(0);
        }
    }

