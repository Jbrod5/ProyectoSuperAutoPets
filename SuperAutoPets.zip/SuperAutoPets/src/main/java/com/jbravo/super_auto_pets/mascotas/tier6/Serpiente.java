package com.jbravo.super_auto_pets.mascotas.tier6;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Serpiente extends Mascota {
    public Serpiente() {
        super.setTier(6);
        super.nombreMascota = "Serpiente";
        super.id = 47;

        super.unidadesDeDanio = 6;
        super.unidadesDeVida = 6;
        super.tipos = TiposDeMascotas.reptil +TiposDeMascotas.separador+ TiposDeMascotas.terrestre + TiposDeMascotas.separador + TiposDeMascotas.desertico;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
