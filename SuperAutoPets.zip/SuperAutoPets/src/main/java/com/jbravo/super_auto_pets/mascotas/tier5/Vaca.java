package com.jbravo.super_auto_pets.mascotas.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Vaca extends Mascota {
    public Vaca() {
        super.setTier(5);
        super.nombreMascota = "Vaca";
        super.id = 42;

        super.unidadesDeDanio = 4;
        super.unidadesDeVida = 6;
        super.tipos = TiposDeMascotas.mamifero + TiposDeMascotas.separador + TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
