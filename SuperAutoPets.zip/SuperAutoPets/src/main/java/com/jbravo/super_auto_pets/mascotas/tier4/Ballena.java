package com.jbravo.super_auto_pets.mascotas.tier4;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Ballena extends Mascota {
    public Ballena() {
        super.setTier(4);
        super.nombreMascota = "Ballena";
        super.id = 33;

        super.unidadesDeDanio = 3;
        super.unidadesDeVida = 8;
        super.tipos = TiposDeMascotas.acuatico;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
