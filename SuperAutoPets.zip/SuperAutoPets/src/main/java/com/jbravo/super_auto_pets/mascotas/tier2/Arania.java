package com.jbravo.super_auto_pets.mascotas.tier2;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Arania extends Mascota {
    public Arania(){
        super.setTier(2);
        super.nombreMascota = "Arania";
        super.id = 16;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.insecto;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
