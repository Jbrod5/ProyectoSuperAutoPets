package com.jbravo.super_auto_pets.mascotas.tier3;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Camello extends Mascota {
    public Camello(){
        super.setTier(3);
        super.nombreMascota = "Camello";
        super.id = 17;

        super.unidadesDeDanio = 2;
        super.unidadesDeVida = 5;
        super.tipos = TiposDeMascotas.mamifero+TiposDeMascotas.separador+TiposDeMascotas.desertico;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
