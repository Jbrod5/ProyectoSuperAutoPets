package com.jbravo.super_auto_pets.powerups.comida;

import com.jbravo.super_auto_pets.powerups.Comida;

public class ComidaEmpty extends Comida {
    public ComidaEmpty(){
        super.setNombre("Espacio Vacio");
        super.setDescripcion(" ");
    }
}
