package com.jbravo.super_auto_pets.mascotas.tier2;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Zorro extends Mascota {
    public Zorro(){
        super.setTier(2);
        super.nombreMascota = "Zorro";
        super.id = 15;

        super.unidadesDeDanio = 5;
        super.unidadesDeVida = 2;
        super.tipos = TiposDeMascotas.solitario + TiposDeMascotas.separador+ TiposDeMascotas.terrestre;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
