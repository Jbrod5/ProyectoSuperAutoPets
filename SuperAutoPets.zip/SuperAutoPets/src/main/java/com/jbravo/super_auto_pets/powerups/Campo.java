package com.jbravo.super_auto_pets.powerups;

public abstract class Campo {

    private String Nombre;
    private String Info;

    public Campo(){

    }

    public abstract void bonificacionCampo();

    public void setNombre(String nombre) {Nombre = nombre;}

    public void setInfo(String info) {Info = info;}

    public String getInfo() {
        return Nombre + " | " + Info;
    }
}
