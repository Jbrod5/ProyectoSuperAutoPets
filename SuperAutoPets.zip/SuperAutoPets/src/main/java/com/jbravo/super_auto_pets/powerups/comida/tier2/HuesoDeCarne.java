package com.jbravo.super_auto_pets.powerups.comida.tier2;

import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class HuesoDeCarne extends Comida {
    public HuesoDeCarne(){
        super.setNombre("Hueso de carne");
        super.setEfecto(true); //a pesar de ser efecto le aumenta el daño a la mascota permanentemente
        super.setDescripcion(" Es tipo efecto, y le da al animal entregado 5 de daño extra durante los turnos de pelea");
    }

    @Override
    public void cambioMascota(int posicionMascota){
        MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].getUnidadesDeDanio()+3);

        MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].setUnidadesDeDanio(MotorDeJuego.jugadorA.mascotasAPelear[posicionMascota].getUnidadesDeDanio()+3);
    }
}
