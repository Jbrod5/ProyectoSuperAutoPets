package com.jbravo.super_auto_pets.mascotas.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Foca extends Mascota {
    public Foca() {
        super.setTier(5);
        super.nombreMascota = "Foca";
        super.id = 36;

        super.unidadesDeDanio = 3;
        super.unidadesDeVida = 8;
        super.tipos = TiposDeMascotas.acuatico + TiposDeMascotas.separador + TiposDeMascotas.mamifero;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
