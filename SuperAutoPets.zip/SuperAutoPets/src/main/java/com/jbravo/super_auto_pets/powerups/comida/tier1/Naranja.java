package com.jbravo.super_auto_pets.powerups.comida.tier1;

import com.jbravo.super_auto_pets.powerups.Comida;

public class Naranja extends Comida {
    public Naranja(){
        super.setEfecto(true);
        super.setNombre("Naranja");
        super.setDescripcion(" Es tipo efecto, hace que regrese un 10% de daño");
    }

     @Override
     public void efectoAlRecibirDanio(int posicionMascota){

    }
}
