package com.jbravo.super_auto_pets.motor;
import com.jbravo.super_auto_pets.mascotas.tier1.Hormiga;
import com.jbravo.super_auto_pets.mascotas.MascotaEmpty;
import com.jbravo.super_auto_pets.mascotas.Perro;

public class Pelea {

    //  ESTE BLOQUE DE CODIGO NO LE CORRESPONDE A PELEA, SINO AL JUEGO (REVISAR MOTOR DE JUEGO O MODO DE JUEGO)
    public Jugador jugadorA = new Jugador();
    public Jugador jugadorB = new Jugador();

    public  Pelea(){
        for (int i = 0; i<5;i++){
            jugadorA.mascotasDisponibles[i] = new Hormiga();
            jugadorB.mascotasDisponibles[i] = new Perro();
        }
        jugadorA.contadorMascotasVivas = 5;
        jugadorB.contadorMascotasVivas = 5;
    } //    ESTE BLOQUE DE CODIGO NO LE CORRESPONDE A PELEA, SINO AL JUEGO (REVISAR MOTOR DE JUEGO O MODO DE JUEGO)

    public void efectosAlInicio(){
        for (int i = 0; i<5; i++) {
            jugadorA.mascotasDisponibles[i].efectoAlInicio();
            jugadorB.mascotasDisponibles[i].efectoAlInicio();
        }
    }

    public void iniciarCombate(){
        jugadorA.mascotasDisponibles[0].recibirDanio(jugadorB.mascotasDisponibles[0].atacar());
        jugadorB.mascotasDisponibles[0].recibirDanio(jugadorA.mascotasDisponibles[0].atacar());
        if(jugadorB.mascotasDisponibles[0].getUnidadesDeVida()==0){
            jugadorB.mascotasDisponibles[0] = new MascotaEmpty();
            jugadorB.contadorMascotasVivas --;
        }
        if(jugadorA.mascotasDisponibles[0].getUnidadesDeVida()==0){
            jugadorA.mascotasDisponibles[0] = new MascotaEmpty();
            jugadorA.contadorMascotasVivas --;
        }
        jugadorA.desplazarMascotas();
        jugadorB.desplazarMascotas();

        if(jugadorA.contadorMascotasVivas > jugadorB.contadorMascotasVivas){
            System.out.println("Jugador A gana con "+jugadorA.contadorMascotasVivas+" mascotas vivas");
            System.out.println("B pierde con " + jugadorB.contadorMascotasVivas);
        }
        if(jugadorA.contadorMascotasVivas< jugadorB.contadorMascotasVivas){
            System.out.println("Jugador B gana con "+jugadorB.contadorMascotasVivas+" mascotas vivas");
            System.out.println("A pierde con " + jugadorA.contadorMascotasVivas);
        }
        if(jugadorA.contadorMascotasVivas == jugadorB.contadorMascotasVivas){
            System.out.println("Es un empate");
        }
    }

    public void iniciarPelea(){
        /*Mascota mascota = new Hormiga;
        jugadorA.setMascotasDisponibles(1,mascota);
        jugadorA.setOro(5);

        jugadorB.setMascotasDisponibles(2,mascota);

        jugadorA.getMascotasDisponibles();*/

        //así es como tendré que controlar sasmamadas :'c '
        /*jugadorA.mascotasDisponibles[1] = new Hormiga();
        jugadorB.mascotasDisponibles[1] = new Hormiga();

        jugadorB.mascotasDisponibles[1].recibirDanio(/*le paso el parametro valor del daño);

        jugadorA.mascotasDisponibles[1].atacar();
        jugadorB.mascotasDisponibles[1].atacar();*/

    }




}
