package com.jbravo.super_auto_pets.mascotas;

public class TiposDeMascotas {
    public static final String insecto      = "Insecto"     ;
    public static final String volador      = "Volador"     ;
    public static final String acuatico     = "Acuatico"    ;
    public static final String terrestre    = "Terrestre"   ;
    public static final String reptil       = "Reptil"      ;
    public static final String mamifero     = "Mamifero"    ;
    public static final String domestico    = "Domestico"   ;
    public static final String solitario    = "Soliitario"  ;
    public static final String desertico    = "Desertico"   ;

    public static final String separador    = "/"           ;
}
