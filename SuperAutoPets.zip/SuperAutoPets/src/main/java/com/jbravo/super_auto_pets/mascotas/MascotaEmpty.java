package com.jbravo.super_auto_pets.mascotas;

public class MascotaEmpty extends Mascota{

    public MascotaEmpty(){
        super.tier = 0;
        super.setTier(0); //hacen lo mismo, lo importante es que super sirve para hacer referencia a la clase superior/padre
        super.nombreMascota = "Espacio vacio";
        super.id = 0;

        super.unidadesDeDanio = 0;
        super.unidadesDeVida = 0;
        super.tipos = " ";
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {

    }
}
