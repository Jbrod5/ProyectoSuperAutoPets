package com.jbravo.super_auto_pets.powerups.comida.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.motor.MotorDeJuego;
import com.jbravo.super_auto_pets.powerups.Comida;

public class Melon extends Comida {

    public Melon(){
        super.setNombre("Melon");
        super.setEfecto(true);
        super.setDescripcion(" Es tipo efecto, y hace que el animal que lo porta la primera vez que sea atacado no reciba daño, solo 1 uso por ronda");
    }

    //al ser atacado la primera vez no recibe danio     solo 1 uso por ronda pero no es destructivo
    //cambia proteccionDanio a true, por eso es un cambiomascota

    @Override
    public void cambioMascota(int posicionMascota){
        MotorDeJuego.jugadorA.mascotasDisponibles[posicionMascota].setProteccionDanio(true);
    }
}
