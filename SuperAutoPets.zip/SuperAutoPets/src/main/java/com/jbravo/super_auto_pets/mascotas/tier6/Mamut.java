package com.jbravo.super_auto_pets.mascotas.tier6;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Mamut extends Mascota {
    public Mamut() {
        super.setTier(6);
        super.nombreMascota = "Mamut";
        super.id = 48;

        super.unidadesDeDanio = 3;
        super.unidadesDeVida = 10;
        super.tipos = TiposDeMascotas.mamifero + TiposDeMascotas.separador + TiposDeMascotas.terrestre + TiposDeMascotas.separador +TiposDeMascotas.solitario;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
