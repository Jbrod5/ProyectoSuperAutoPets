package com.jbravo.super_auto_pets.mascotas.tier6;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Tigre extends Mascota {
    public Tigre() {
        super.setTier(6);
        super.nombreMascota = "Tigre";
        super.id = 46;

        super.unidadesDeDanio = 4;
        super.unidadesDeVida = 5;
        super.tipos = TiposDeMascotas.terrestre + TiposDeMascotas.separador + TiposDeMascotas.mamifero;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
