package com.jbravo.super_auto_pets.mascotas.tier5;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Escorpion extends Mascota {
    public Escorpion() {
        super.setTier(5);
        super.nombreMascota = "Escorpion";
        super.id = 38;

        super.unidadesDeDanio = 1;
        super.unidadesDeVida = 1;
        super.tipos = TiposDeMascotas.desertico + TiposDeMascotas.separador + TiposDeMascotas.solitario;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {
        super.comida.efectoAlMorir(0);
    }
}
