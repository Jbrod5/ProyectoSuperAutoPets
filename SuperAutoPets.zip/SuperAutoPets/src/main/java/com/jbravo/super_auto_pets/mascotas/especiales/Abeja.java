package com.jbravo.super_auto_pets.mascotas.especiales;

import com.jbravo.super_auto_pets.mascotas.Mascota;
import com.jbravo.super_auto_pets.mascotas.TiposDeMascotas;

public class Abeja extends Mascota {

    public Abeja (){
        super.setTier(1);
        super.nombreMascota = "Abeja";
        super.id = 0;

        super.unidadesDeDanio = 1;
        super.unidadesDeVida = 1;
        super.tipos = TiposDeMascotas.insecto;
    }

    @Override
    public void efectoAlInicio() {

    }

    @Override
    public void efectoEnTurno() {

    }

    @Override
    public void efectoAlSubirDeNivel() {

    }

    @Override
    public void efectoAlMorir() {

    }
}
