package com.jbravo.super_auto_pets.motor;

public class Jugador extends Entidad{

}
